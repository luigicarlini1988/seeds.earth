<!DOCTYPE html>
<html>
<header>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</header>

<body>
    <div id="app" class="content-main">
        <div class="header fixed-top">
            <div class="d-flex justify-content-center">
                <div class="outer-wrapper">
                    <div class="frame">
                        <img src="<?php echo plugins_url('../img/pay-with-seeds.svg', __FILE__ ); ?>" class="logo" alt="logo">
                    </div>
                </div>
            </div>
            <div class="language-container">
                <div class="dropdown">
                    <button class="btn btn-sm btn-secondary dropdown-toggle btn-language" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        {{ labelLanguage }}
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" v-if="translates">
                        <div v-if="translates && translates.languages" v-for="(language, index) in translates.languages">
                            <a v-if="selectedLanguage.key === language.key" class="dropdown-item active"  @click="setPreferredLanguage(language)">{{language.label}}</a>
                            <a v-else class="dropdown-item" @click="setPreferredLanguage(language)">{{language.label}}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
                <?php
                    if(isset($_POST['SaveConfigsSeedJoin'])){ //check if form was submitted
                        $style_btn = $_POST['styleBtnInput'];
                        $style_theme = $_POST['styleThemeInput'];
                        $button_position = $_POST['buttonPositionInput'];
                        if (
                            $wpdb->query(
                                "INSERT into {$wpdb->prefix}seeds_pay_config
                                (id, style_btn, style_theme, button_position)
                                values (1, '".$style_btn."', '".$style_theme."', '".$button_position."')
                                ON DUPLICATE KEY UPDATE
                                style_btn = '".$style_btn."',
                                style_theme= '".$style_theme."',
                                button_position= '".$button_position."';"
                            )
                        ) {
                            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ language.configuration_updated }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>';
                        } else {
                            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ language.configuration_saved }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>';
                        }
                    }  
                ?>
            <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="config-tab" data-toggle="tab" href="#config" role="tab"
                        aria-controls="config" aria-selected="true">Configuration</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="transaction-tab" data-toggle="tab" href="#transaction" role="tab"
                        aria-controls="transaction" aria-selected="false">Transactions List</a>
                </li>
            </ul>
            <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="config" role="tabpanel" aria-labelledby="config-tab">
                    <div class="custom-card">
                        <div class="row justify-center">
                            <div class="col-md-12">
                                <div class="form-group">
                                    <label for="OrgId">
                                        <!-- <p><strong>Private Key</strong></p> -->
                                        <p><strong>{{ language.organization_name }}</strong></p>
                                    </label>
                                    <input v-model="orgId" type="text" class="form-control custom-input" id="OrgId"
                                        aria-describedby="Org Id">
                                        <small id="orgIdHelp" class="form-text text-muted ml-2">{{ language.organization_name_help }}</small>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="amount">
                                        <!-- <p><strong>Private Key</strong></p> -->
                                        <p><strong>{{ language.local_amount }}</strong></p>
                                    </label>
                                    <input v-model="localAmount" type="number" class="form-control custom-input" id="localAmount"
                                        aria-describedby="localAmount">
                                        <small id="orglocalAmount" class="form-text text-muted ml-2">{{ language.local_amount_help }}</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="currentCurrency">
                                        <p><strong>{{ language.current_symbol }}</strong></p>
                                    </label>
                                    <select v-model="currentSymbol" class="form-control custom-select" id="currentCurrency">
                                        <option v-for="currency in currenciesOptions" :value="currency.code">
                                        {{ currency.name }} ({{ currency.symbol }})
                                        </option>
                                    </select>
                                    <small id="orgIdHelp" class="form-text text-muted ml-2">{{ language.current_symbol_help }}</small>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="amount">
                                        <!-- <p><strong>Private Key</strong></p> -->
                                        <p><strong>{{ language.seeds_amount }}</strong></p>
                                    </label>
                                    <input v-model="seedsAmount" type="number" class="form-control custom-input" id="amount"
                                        aria-describedby="Amount">
                                        <small id="orgIdHelp" class="form-text text-muted ml-2">{{ language.seeds_amount_help }} <span ><a href="https://www.telos.bloks.io/account/tlosto.seeds?loadContract=true&tab=Tables&account=tlosto.seeds&scope=tlosto.seeds&limit=100&table=price" target="_blank">{{ language.seeds_amount_here_help }}</a></span>.</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="email">
                                        <!-- <p><strong>Private Key</strong></p> -->
                                        <p><strong>{{ language.email }}</strong></p>
                                    </label>
                                    <input v-model="email" type="email" class="form-control custom-input" id="email"
                                        aria-describedby="Email">
                                        <small id="orgIdHelp" class="form-text text-muted ml-2">{{ language.email_help }}</small>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="imageUrl">
                                        <!-- <p><strong>Private Key</strong></p> -->
                                        <p><strong>{{ language.imageUrl }}</strong></p>
                                    </label>
                                    <input v-model="imageUrl" type="url" class="form-control custom-input" id="imageUrl"
                                        aria-describedby="Image URL">
                                        <small id="orgIdHelp" class="form-text text-muted ml-2">{{ language.image_help }}</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="productName">
                                        <!-- <p><strong>Private Key</strong></p> -->
                                        <p><strong>{{ language.productName }}</strong></p>
                                    </label>
                                    <input v-model="productName" type="text" class="form-control custom-input" id="productName"
                                        aria-describedby="Product Name">
                                        <small id="orgIdHelp" class="form-text text-muted ml-2">{{ language.product_name_help }}</small>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="productDescription">
                                        <!-- <p><strong>Private Key</strong></p> -->
                                        <p><strong>{{ language.productDescription }}</strong></p>
                                    </label>
                                    <input v-model="productDescription" type="text" class="form-control custom-input" id="productDescription"
                                        aria-describedby="Product Description">
                                        <small id="orgIdHelp" class="form-text text-muted ml-2">{{ language.description_help }}</small>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="urlCallback">
                                        <!-- <p><strong>Private Key</strong></p> -->
                                        <p><strong>{{ language.callback }}</strong></p>
                                    </label>
                                    <input v-model="urlCallback" type="url" class="form-control custom-input" id="urlCallback"
                                        aria-describedby="Url Callback">
                                        <small id="orgIdHelp" class="form-text text-muted ml-2">{{ language.callback_help }}</small>
                                </div>
                            </div>
                        </div>
                        <p><strong>{{ language.choose_btn }}</strong></p>
                        <div class="row p-3 justify-content-center">
                            <div class="col-lg-3 col-md-4 text-center p-3">
                                <div class="row align-items-center">
                                    <div class="col-2">
                                        <input class="form-check-input" type="radio" name="radioStyleBtn"
                                            id="radioStyleBtnDark" v-model="styleBtn" value="dark">
                                    </div>
                                    <div class="col-8">
                                        <img class="btnImage"
                                            src="<?php echo plugins_url('../img/pay-dark.svg', __FILE__ ); ?>"
                                            @click="styleBtn='dark'">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4 text-center p-3">
                                <div class="row align-items-center">
                                    <div class="col-2">
                                        <input class="form-check-input" type="radio" name="radioStyleBtn"
                                            id="radioStyleBtnLight" v-model="styleBtn" value="light">
                                    </div>
                                    <div class="col-8">
                                        <img class="btnImage"
                                            src="<?php echo plugins_url('../img/pay-light.svg', __FILE__ ); ?>"
                                            @click="styleBtn='light'">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4 text-center p-3">
                                <div class="row align-items-center">
                                    <div class="col-2">
                                        <input class="form-check-input" type="radio" name="radioStyleBtn"
                                            id="radioStyleBtnWhite" v-model="styleBtn" value="white">
                                    </div>
                                    <div class="col-8">
                                        <img class="btnImage"
                                            src="<?php echo plugins_url('../img/pay-white.svg', __FILE__ ); ?>"
                                            @click="styleBtn='white'">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p><strong>{{ language.choose_multistep }}</strong></p>
                        <div class="row justify-content-center p-3">
                            <div class="col-md-6 text-center p-3">
                                <input type="radio" name="radioStyleTheme" id="radioStyleThemeDark" v-model="styleTheme"
                                    value="dark">
                                <img class="themeImage"
                                    :src="darkThemeImage"
                                    @click="styleTheme='dark'">
                            </div>
                            <div class="col-md-6 text-center p-3">
                                <input type="radio" name="radioStyleTheme" id="radioStyleThemeLight"
                                    v-model="styleTheme" value="light">
                                <img class="themeImage"
                                :src="lightThemeImage"
                                    @click="styleTheme='light'">
                            </div>
                        </div>
                        <p><strong>{{ language.choose_place_btn }}</strong></p>
                        <div class="row justify-content-center p-3">
                            <div class="col-md-6 text-center p-3">
                                <p class="p-2">{{ language.btn_left }}</p>
                                <input type="radio" name="radioButtonPosition" id="radioButtonPositionLeft"
                                    v-model="buttonPosition" value="left">
                                <img class="themeImage"
                                src="<?php echo plugins_url('../img/button-on-left.png', __FILE__ ); ?>"
                                    @click="buttonPosition='left'">
                            </div>
                            <div class="col-md-6 text-center p-3">
                                <p class="p-2">{{ language.btn_right }}</p>
                                <input type="radio" name="radioButtonPosition" id="radioButtonPositionRight" v-model="buttonPosition"
                                    value="right">
                                <img class="themeImage"
                                    src="<?php echo plugins_url('../img/button-on-right.png', __FILE__ ); ?>"
                                    @click="buttonPosition='right'">
                            </div>
                        </div>
                        <div class="row" v-if="allFieldsFilled">
                            <div class="col-sm-6 mt-2">
                                <p><strong>{{ language.manual_configuration }}</strong></p>
                                <p class="p-2">{{ language.full_code_description }}</p>
                                <div class="input-group">
                                    <textarea class="form-control" id="exampleFormControlTextarea1"
                                        readonly>{{fullcode}}</textarea>
                                    <div class="input-group-prepend pointer">
                                        <div class="input-group-text" @click="copyToClipboard(fullcode)">{{ language.copy }}</div>
                                    </div>
                                    <!-- <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Username"> -->
                                </div>
                            </div>
                            <div class="col-sm-6 mt-2">
                                <p><strong>{{ language.automatically_configuration }}</strong></p>
                                <p class="p-2">{{ language.short_code_description }}</p>
                                <div class="input-group">
                                    <textarea class="form-control" id="exampleFormControlTextarea1"
                                        readonly>{{shortcode}}</textarea>
                                    <div class="input-group-prepend pointer">
                                        <div class="input-group-text" @click="copyToClipboard(shortcode)">{{ language.copy }}</div>
                                    </div>
                                    <!-- <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Username"> -->
                                </div>
                            </div>
                        </div>
                        <div v-else>
                            <small id="fields Help" class="form-text  ml-2">{{ language.help_fields_filled }}</small>
                        </div>
                    </div>
                    <div class="mt-3 text-center">
                        <form method="post" action="" >
                            <div class="form-hidden">
                                <input v-model="styleBtn" type="text" class="form-control custom-input"
                                        name="styleBtnInput" aria-describedby="StyleBtn">
                                <input v-model="styleTheme" type="text" class="form-control custom-input"
                                        name="styleThemeInput" aria-describedby="styleTheme">
                                <input v-model="buttonPosition" type="text" class="form-control custom-input"
                                        name="buttonPositionInput" aria-describedby="buttonPosition">
                            </div>
                            <button name="SaveConfigsSeedJoin" class="btn btn-save">{{ language.save }}</button>
                        </form>
                    </div>
                </div>
            
                <div class="tab-pane fade" id="transaction" role="tabpanel" aria-labelledby="transaction-tab">
                    <div class="custom-card">
                        <!-- <button class="btn btn-refresh" @click="getTransactions"> {{ language.refresh }}</button> -->
                        <table class="table table-hover" v-if="transactionListOptimized">
                            <thead>
                                <tr>
                                <th scope="col">#</th>
                                <th scope="col">From</th>
                                <th scope="col">To</th>
                                <th scope="col">Quantity</th>
                                <th scope="col">Memo</th>
                                <th scope="col">Product Name</th>
                                <th scope="col">Date</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr v-for="transaction in transactionListOptimized">
                                <th scope="row">{{transaction.id}}</th>
                                <td>{{transaction.data.from}}</td>
                                <td>{{transaction.data.to}}</td>
                                <td>{{transaction.data.quantity}}</td>
                                <td>{{transaction.data.memo}}</td>
                                <td>{{transaction.data.product_name}}</td>
                                <td>{{transaction.date}}</td>
                                </tr>
                            </tbody>
                        </table>
                        <!-- value: {{ transactionList }} -->
                    </div>
                </div>
            </div>
            </div>
        </div>
    </div>
    </div>
</body>
<script>
    const myStorage = window.localStorage;
    var app = new Vue({
        el: '#app',
        data() {
            return {
                orgId: undefined,
                styleBtn: undefined,
                styleTheme: undefined,
                buttonPosition: undefined,
                selectedLanguage: undefined,
                translates: undefined,
                amount: undefined,
                email: undefined,
                imageUrl: undefined,
                productName: undefined,
                productDescription: undefined,
                urlCallback: undefined,
                currentSymbol: 'USD',
                localAmount: undefined,
                seedsAmount: undefined,
                currenciesOptions: undefined,
                transactionList: undefined,
                currentUrl: undefined
            }
        },
        async beforeMount () {
            this.translates = await this.getTranslates()
            this.selectedLanguage = this.getDefaultLanguage()
            this.currenciesOptions = await this.getAllCurrencies()
            this.getTransactions()
            this.currentUrl = this.fetchCurrentUrl()
            this.urlCallback = this.currentUrl
        },
        mounted() {
            this.styleBtn = this.fetchStyleBtn();
            this.styleTheme = this.fetchStyleTheme();
            this.buttonPosition = this.fetchButtonPosition();

            this.styleBtn = this.styleBtn ? this.styleBtn : 'light'
            this.styleTheme = this.styleTheme ? this.styleTheme : 'light'
            this.buttonPosition = this.buttonPosition ? this.buttonPosition : 'left'
            //button_position
        },
        computed: {
            shortcode() {
                const id = Math.floor(Math.random() * 16777215).toString(16);
                return `[shortPayWithSeeds id="${id}" accountName="${this.orgId}" btnStyle="${this.styleBtn}" multiStepStyle="${this.styleTheme}" buttonPosition="${this.buttonPosition}" amount="${this.amount}" email="${this.email}" productImage="${this.imageUrl}" productName="${this.productName}" productDescription="${this.productDescription}" callback="${this.urlCallback}"]`;
            },
            fullcode () {
                const id = Math.floor(Math.random() * 16777215).toString(16);
                const classContainer = (this.buttonPosition === 'right')? "pay-seed-btn-bottom-right": "pay-seed-btn-bottom-left";
                let code = "<div id='pay-with-seeds-"+id+"' class='"+classContainer+"'></div>\n";
                code += "<script src=\"https://seeds-cdn.s3.amazonaws.com/js/paywithseeds.js\"></"+"script>\n";
                code += "<script>\n";
                code += `new PayWithSeeds`+"("+`\"pay-with-seeds-${id}\", {\"account_name\":\"${this.orgId}\",\"button_theme\":\"${this.styleBtn}\",\"multistep_theme\":\"${this.styleTheme}\",\"amount\":\"${this.amount}\",\"email\":\"${this.email}\",\"product_image\":\"${this.imageUrl}\",\"product_name\":\"${this.productName}\",\"product_description\":\"${this.productDescription}\",\"callback\":\"${this.urlCallback}"\}`+"\)"+`;`;
                code += "\n</"+"script>";
                
                return code;
            },
            labelLanguage () {
                if (this.selectedLanguage) {
                    return this.selectedLanguage.label
                } else return 'Language'
            },
            language () {
                console.log(this.selectedLanguage)
                if (this.translates && this.selectedLanguage && this.selectedLanguage.key) { 
                    return this.translates[this.selectedLanguage.key]
                } return {}
            },
            darkThemeImage () {
                let uri = <?php echo '"'.plugins_url('../img/', __FILE__ ).'"'; ?>;
                const imageName = "/dark-theme.png";
                const languageFolder = this.selectedLanguage ? this.selectedLanguage.key : "en";
                return uri + languageFolder + imageName;
            },
            lightThemeImage () {
                let uri = <?php echo '"'.plugins_url('../img/', __FILE__ ).'"'; ?>;
                const imageName = "/light-theme.png"
                const languageFolder = this.selectedLanguage ? this.selectedLanguage.key : "en"
                return uri + languageFolder + imageName
            },
            allFieldsFilled () {
                return (
                    this.orgId
                    && this.styleBtn
                    && this.styleTheme
                    && this.buttonPosition
                    && this.localAmount
                    && this.seedsAmount
                    && this.email
                    && this.imageUrl
                    && this.productName
                    && this.productDescription
                )
            },
            transactionListOptimized () {
                if (!this.transactionList) return undefined
                return this.transactionList.map(transaction => {
                    return {
                        ...transaction,
                        data: JSON.parse(transaction.data)
                    }
                })
            }
            
        },
        methods: {
            async getTransactions () {
                this.transactionList = undefined
                await this.$nextTick()
                console.log('getTransactions')
                this.transactionList = await this.fetchPurchasesList()
                await this.$nextTick()
            },
            setPreferredLanguage (language) {
                this.selectedLanguage = language
                myStorage.setItem('language_preferred', language.key)
            },
            getDefaultLanguage () {
                let lang = window.navigator.languages ? window.navigator.languages[0] : null;
                lang = lang || window.navigator.language || window.navigator.browserLanguage || window.navigator.userLanguage;

                let shortLang = lang;
                if (shortLang.indexOf('-') !== -1)
                    shortLang = shortLang.split('-')[0];

                if (shortLang.indexOf('_') !== -1)
                    shortLang = shortLang.split('_')[0];

                // Get language saved
                let keyLang = myStorage.getItem('language_preferred') ? myStorage.getItem('language_preferred') : shortLang
                keyLang = (keyLang && keyLang !== '' && keyLang.length > 1) ? keyLang : 'en'
                keyLang = (keyLang.toLowerCase() !== 'en' && keyLang.toLowerCase() !== 'es') ? 'en' : keyLang

                // console.log(lang, shortLang);
                const langSelected = this.translates.languages.find(v => v.key === keyLang)
                return langSelected
            },
            async getTranslates () {
                const uri = <?php echo '"'.plugins_url('translates.json', __FILE__ ).'";'; ?>
                // const json = await (await fetch(uri)).json()
                const json = await (await fetch(uri)).json()
                // console.log('json: ', json)
                return json
            },
            async getAllCurrencies () {
                const uri = <?php echo '"'.plugins_url('symbols.json', __FILE__ ).'";'; ?>
                // const json = await (await fetch(uri)).json()
                const json = await (await fetch(uri)).json()
                // console.log('json: ', json)
                return json
            },
            copyToClipboard(text) {
                // var text = this.shortcode;
                navigator.clipboard.writeText(text).then(() => {
                    // https://www.cssscript.com/super-simple-javascript-message-toaster-toast-js/
                    iqwerty.toast.toast(this.language.copy_success, {
                        settings: {
                            duration: 2000,
                        }
                    });

                }, function (err) {
                    iqwerty.toast.toast(this.language.copy_error, {
                        settings: {
                            duration: 2000,
                        }
                    });
                });
            },
            // fetchPrivateKey () {
            //     const pk = <?php 
            //         $data = $wpdb->get_row("SELECT private_key FROM {$wpdb->prefix}seeds_pay_config where id=1"); 
            //         echo "\"".$data->private_key."\"";
            //     ?>;
            //     return pk
            // },
            fetchStyleBtn () {
                return <?php 
                    $data = $wpdb->get_row("SELECT style_btn FROM {$wpdb->prefix}seeds_pay_config where id=1"); 
                    echo "\"".$data->style_btn."\"";
                ?>;
            },
            fetchStyleTheme () {
                return <?php 
                    $data = $wpdb->get_row("SELECT style_theme FROM {$wpdb->prefix}seeds_pay_config where id=1"); 
                    echo "\"".$data->style_theme."\"";
                ?>;
            },
            fetchButtonPosition () {
                return <?php 
                    $data = $wpdb->get_row("SELECT button_position FROM {$wpdb->prefix}seeds_pay_config where id=1"); 
                    echo "\"".$data->button_position."\"";
                ?>;
            },
            fetchPurchasesList () {
                // return 'Hi'
                return <?php 
                    $data = null;
                    $data = $wpdb->get_results("SELECT * FROM {$wpdb->prefix}seeds_pay_purchases_list"); 
                    echo json_encode($data);
                ?>;
            },
            fetchCurrentUrl () {
                // return 'Hi'
                return <?php  
                    global $wp;
                    $current_url = home_url( add_query_arg( array(), $wp->request ) ) . add_query_arg( array(), $wp->request );   
                    $callback_url =  $current_url . "/wp-json/paywithseeds/v1/purchases" ;
                    echo json_encode($callback_url);
                ?>;
            }
        }
    });
</script>
</html>