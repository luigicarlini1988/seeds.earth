<?php
/*
Plugin Name: Pay With Seeds
Plugin URI: https://joinseeds.earth/pay-with-seeds
Description: Pay through seeds
Version: 0.1.6
*/

//Import class
require_once dirname(__FILE__)."/public/shortcodes/ShortcodePayWithSeeds.php";

function ActivatePayWithSeedsPlugin() {
    // echo 'Activate';
    global $wpdb;

    $SQL = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}seeds_pay_config
    (
    `id` INT NOT NULL ,
    `private_key` VARCHAR(100) NOT NULL ,
    `style_btn` VARCHAR(100) NOT NULL,
    `style_theme` VARCHAR(100) NOT NULL,
    `button_position` VARCHAR(100) NOT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE = InnoDB COMMENT = 'Seeds Plugin (Pay with seeds)';";

    $SQL2 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}seeds_pay_purchases_list
    (
    `id` INT NOT NULL AUTO_INCREMENT ,
    `date` TIMESTAMP NOT NULL ,
    `data` JSON NOT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE = InnoDB COMMENT = 'Seeds Plugin (Purchases list from pay with seeds)';";

    // - Date/time
    // - SEEDS Account Name
    // - Amount (in Seeds)
    // - Memo
    $wpdb->query($SQL);
    // $wpdb->query("DROP table {$wpdb->prefix} seeds_pay_purchases_list");
    $wpdb->query($SQL2);
}

// function Desactivate () {
// }

register_activation_hook(__FILE__,'ActivatePayWithSeedsPlugin');
// register_deactivation_hook(__FILE__,'Desactivate');

#Add menu
add_action('admin_menu','create_menu_to_pay_with_seeds');

function create_menu_to_pay_with_seeds () {
    $icon_base64 = 'PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iVVRGLTgiIHN0YW5kYWxvbmU9Im5vIj8+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgdmVyc2lvbj0iMS4xIiBpZD0iTGF5ZXJfMSIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgeD0iMHB4IiB5PSIwcHgiIHdpZHRoPSI0NzhweCIgaGVpZ2h0PSI0NzhweCIgdmlld0JveD0iMCAwIDQ3OCA0NzgiIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXcgMCAwIDQ3OCA0NzgiIHhtbDpzcGFjZT0icHJlc2VydmUiPiAgPGltYWdlIGlkPSJpbWFnZTAiIHdpZHRoPSI0NzgiIGhlaWdodD0iNDc4IiB4PSIwIiB5PSIwIgogICAgeGxpbms6aHJlZj0iZGF0YTppbWFnZS9wbmc7YmFzZTY0LGlWQk9SdzBLR2dvQUFBQU5TVWhFVWdBQUFkNEFBQUhlQ0FNQUFBQUNRSnJ4QUFBQUJHZEJUVUVBQUxHUEMveGhCUUFBQUNCalNGSk4KQUFCNkpnQUFnSVFBQVBvQUFBQ0E2QUFBZFRBQUFPcGdBQUE2bUFBQUYzQ2N1bEU4QUFBQXExQk1WRVgvLy84clNEVXJTRFVyU0RVcgpTRFVyU0RVclNEVXJTRFVyU0RVclNEVXJTRFVyU0RVclNEVXJTRFVyU0RVclNEVXJTRFVzY2pndXh6NHYzRUF0aURvc1hUY3VzajB2CjhVRXJVell0blRzc2ZUa3V2VDB2NTBBdHB6d3NhRGN0a2pvdTBqOHFVVFVwV1RRblpqUW5hak1sZHpNbGV6TWtmek1qakRJamlESW0KYmpNb1hUUXBWVFFraERJb1lqUW1jek1xVERVczFUNHJaVGN1NjBBcWl6Z3NuRG90M0Q0dHRUMy8vLy9GUjRibUFBQUFFSFJTVGxNQQpNRUFRWUlDUXdOQ2djRkR3SUxEZ2lZeG02QUFBQUFGaVMwZEVBSWdGSFVnQUFBQUpjRWhaY3dBQUxpTUFBQzRqQVhpbFAzWUFBQUFICmRFbE5SUWZsQkFjVk5qUE9LeThRQUFBZDJFbEVRVlI0MnUyZGFVUGl6TktHaDkwRkJIVWNjRVFIRVhGRDVkMy8vejk3VFVnZ1NWY24KdmFXcUsvVDE1WnhuWnNTWTI2cXVyYnQvL1FvRUFnSFBhYlZUcUo4a1lFMm4zZTcyZXYzQkR4TUpKejkvZDlycm5iWGJMZXFuRGFqUgphWjlIbWc0bnVwejhLTjF0ajZpZlB5RGh4MWd2QnRxcUFqTC9tSE9IK29jSkhHaDFlNE94dmJCWmhvUCtXVmlpeVdsMSt3NHNWbXJKCkY3MmdNUkdkODE2TnltWTBQdTJHeUF1WFVmZjBCRVBhbE9IRldaQVloODc1cWVPRk5ranNDKzArcXRVV0daOTJRMUJkRTUzdWhYNDYKNjU2VFlNVHVHWjJSbW0yZWNUOEUxQTVwOVR6U2RzZnc5Sno2clRTRDBSbEpKQlVVUnNBcm55d3k3b2QxMkp6dUJiVitDZ3FmaFRhRQpDYTFUSCtKa0ZTNjYxTytLRzUydTEwNjV5TEFmVEZnZFBvWjdZQkJNV0kwdVNxZkFQZU5lcUdoVjBlbDVtZ1lwY1JvQzZUSkdwOVFDCjJUSUl1YkNNTm9NOHFKcHhXSVFoMmt5WFhFRGdzQWdYNFpVSVZURU1BbWZwY282bmdzRGxORS9jSVBDZWRxUGNjaEE0TDI1akFpcUkKSTQraVI0MUloVW9GUHQ0OHVNTytpS0hDNEVnSGQzcjgrZ1ptbkI1aE8rbThrZUV5ek5IRldLTkdSMVFpUjdVRWQzclVyeHVmd2RGNAo2R1B5eXhtT3cwTWZtMTgrTUQ2Q0dQcnNXT0psaUl1R0czQ3JzUlZJTllabjFBclV5UkdHVkVXYUcySWR1K251YUtvQkI5Tk5hS0lCCkI5TTlNR3hjSSttTStwWDZSYk5DNk03UjVyb3loZzNLZ2MrUE9kZVYwYWRXeFJWOTZqZnBKeWVOaUxCR0lhYVNNR3hBR3lrNDVoTFkKTytqZ21Fdmg3YUE3d1RGWHdObEJ0NE5qcnFaSHJaSXBvWlNoQk5NU3gxR011YnJnaE9HbTc3RHNxc092aE5VS3k2NE96SnFFM2FDdQpIcWZVaXVrUWdpcHRCbndDckJCVUdjQ2x3aEc2ZjJZTVdRVFFJV1EyaFVNQTNUck9MUWh1OEg1SUp5UkVWbml1YjFEWEVxOFRwQzcxCjIrR1B4L29HZFIzZ3JiNUJYU2Q0cW05UTF4RW5QaGF3Z3JyTzhGRGZvSzVEdk5NM3FPc1V6L1FONmpyR0szMkR1czd4U04rZ2JnMTQKa3g4RmRXdkJFMzJEdWpYaGhiNHQ2cmZRWER6UU4vU0lhb1I4Z0RLb1d5dkUvZDlPbU0yb0YxSjl3MXhWM1pETzE0V1p5Tm9oMURmTQpNeU5BVnI0S2V4RlFPS0ZSTjVRemtDQkpmME5LaEFiQkJ2NU9VQmNQL1BRb3BFU0lvSWZQSVdoR1pZd2JQb2VnR1prQnBycHQ2cC8yCitFQTh3QzZFVlFUZ2hWY2hyQ0lBTGJ3SzUwU1NnRlNkUEtmK09ZK1ZDd3gxUjJIaHBRSmplSVB6d250NWRmMmIraGxzcUgvNVpiencKM3Z5Wi9uQjlTZjBjNXRSZTNlQzc4TTV1cHdsWE45VFBZa3pOelNPK0dlL2Y2K21CMnhuMTQ1aFM3K25lWEtkdlpuZlRIR3c5OUxETwpzK3U0bHByL3pxZEY3cGthY0kzRlo2WWJFb3FtbXhqd0EvVnptVkZmYjU5blRuUjVQWVg1Ui8xa1p0U1ZIZkc4b2ZYZlZNb2RTd2RkCjAyZ2RTOWNNTzJiZURyb2U5OHpSTmQ4c3BxWE1XUmF4Nm5EUEhGM3p3M3hhQmNjRnVBYjN6TkUxLzY1V2R6cjlRLzJVQnJoM3p3eGQKODI4RmNabnE2OW85TXl4b0tLbzduVjd4QzZBZEZ6Y1lObm1WMVoxT0YvejBkZHY2NVZkcjFsQ1hvNzVEbDYxQmZtMUFMWFduMHp2cQo1OVhHNFdRT3Z5TVdOTlhsR0YrNXV6YUZYY3I3SUZQeCtxb3grbzVkcVR1aS9rbDBrVll6L3N6a0pXaDI5U3RYeVMrM3VHb21xVVR1CktwQVBzZ1lTdHc2L284NCt1N2hLNG9BWFNmOUExbVdZY3h2QmNqTjR4UzJ1dW9YVnl4UXY3aVg2YzB1UFhFUlgzT0txdndxaDAyK0YKZjhNQUI3VXJick9STXppc3VzMy9LMG16NFMvMTAydGl2MnVRMnpaOGVPRVZ3bUk0dU9hMi9GcVB0WE5MaXY2cHFTdlQ5NHI2K1RXeApUWTR1cUg4QVBXN21pdXJLOUdYVzNiY3NQWE03WmVGS1E3TExKcmhudXpNWm1GVTBRTmNzallmQitKbWJlN2FwYlRBelhqQnFMbWtHCmdiOE56S0pubTlvR3N3bWNQNEJhcGJVSzZBdXVtUlUzek0yWDJhR2dVSitvWWkyRnF0TzNpdC9PRTh6TmwxazVFb3FyS2x3dEZHbHoKaTY1TXpaZVo4VUtSOEgzVkYwRWxUR2ExU1ZQejVXKzhpK3F2Z3RvTFIyRytEVEJlaFMxRU02RDlleFRteXl4c0JveFhLVWlDZmkyTwp3SHlaNWJ5QVNndTFyd1RjOHhHWUw3T0NGV0M4aXRNMVVER2s4Ymt2TStPOUVTVlNubDBHaXBPTnozMlp0WXFBK3BQNkFpb1dONjZwCmZ4NDl0QnRIelBxOGdJUFZXRCtCZFp0WjVWbTM3OHRzU09PM2pmRkNDemV6WFNsRFBYVTcxTStyeWNMR2VFSHpaWlliNlUxZE1SdVAKZkxDVlJ6UmZabU1iZWx0U21OVWo3KzJNRnlvOUw2aC9KazEwWnA2WjFTTW4xNWJHNitJVGlOSFpFTXFzcENINlp1M0lTQnpjWU9hZApOVW9iM0U3QkVYMnpkbDR6WSsrZDFYTWpabG1SR0RjYlZDWEV1Z2d6NzZ5Y0czSGJkeUlXSkN1NytDSmljTVZ0dzY5cWJzUXRzQkpyCkdpWkhSUXAxTDJhVkRlVU5aY3dhdlJOaHY2NVJ4Vmp3em5QcW4wc1h0ZUNLVzJBbDJwMkJiNGE4TTdmall0VjJMSEFMck1TbDErd1kKQmZhcGtWcHd4U3l3RXBkZVE2OHErSGhtTXh0cTE2UndDNnpFck5jd0poSXFHd3ZxbjB3WGxjb1ZzejQrMEE0d2RLcGk3WXY2SjlPbQp1cXZQckk4L0FkWk0wNUJJQ05HNEhZV2trUHI2Y2JMdjQvSnA5YngrZWMzd3RsNi9yejZXd2orOWNXWjBCVGN3L3lNTzFHMldxOVU2Ci8xeWZrdWVpb1BxWWR2S2tkL1Axdm40dDRmTjVsWHVYUWl2ZWVJZHU3c1NreGUrQ3VKdW43eGVkNXlLaEt2V2w5YzJicCtlM1Z4VmUKM2ovU3J4RWlJcU9zTnlLVCtWN2wvZkxtYWEzMFdEL1BSU3R4MVRIUGhMNzU0LzFUN1IwbVBIOXRveThUVGlrelRsY2ZZSEUvdnRWKwo1ZEpGSkhrdUVxcThNOVdZeGtidkhTWkVYeWtFenVZQlVlS1dzeCtncVczK040K0E4a3NXYUFxUzJ5Yzl1OTI3d3VpTEJYbk5HM25SCnlFYjJacVBIbGRselJUYjh2U0Y1bGVXRlNZb1J1czIzNlR0Y3A1bzR5bGF2Y2hlRExwOU5ueXY1NWZzaWVKbmwzaGsvYmw0cUJpMVMKZVIyVkpDUCtMQTRwODVmRmM2VjhycmJvNzdNc2RrYVBtMjNFZlgxOWp6N0NXVjcwazBMdi85K1hzVmZPODRZdWNGbnNqQnczMjRuNworcnFLUHNTaHZQdm5lckY3cnB6QVQ3anZ0TXc3by9ybVIrTTFOeXV2dTZyRy9ya2N1T1VzbjdpcHNOdzdvMjQ5V1psa0hBcnlHbGMxCmRteFhic1dOV0c4UjM2dTg3b3phQzNUdzJrQjU3YmJtTGgwdHV1S0RZaUh2Q3FMMkFuMlVkMnVaQy9rZzcwUXFMK3FjaG9meTFtTzYKMlBMS1pqWnd6MXZ3VDk0YVZsMEtlV1dGcXo3bVEzZ243OVp4d0p3RnRYNGwyd3VLVzdLcVMxN0RTYXVOZlNBdng0ZlVDSGxIdmlONQpoUWtwczd6M3EwWnhzZVdGVXlQazI4WWNoREh1cWxidnRhcUxMQytjR2lHUHJ6dFk2cjZqenluS3V6QjRGdXY2bVZmeXd1UHN5SjE4CkIvS0NIU1A5aG1CZDJlNEIzRGNMOXZTeHUwVU9MQ2FXZDJFcjc5WmhBOEVQZWFHdUVmYnVCQWRaNW1mME9iYkRPQWpxdmlHL1dtangKeGQ0NTl1VElLb1NObTNvSEx5Q291L015aUVDTEwvYWd4dExCZTN1Y0FKT1NlbldOMnRmZDF5UUV4RVJjZk5IUG9YdDA4TjZpaUZUWQpJS2hWMTZnN1pvNUJyVWxHaUlzdi9oM2JEdDViVk93VHlsWTZlL05yem5jVFBqU2V5QW5pQWNENE01SU9NaU93cnFGeDFuYTl0YW85CjZET3hZdGtaLzZReVY1bVJNQW1ySEZ0dGNOVEZ6b3Ntd0U1US9FZHdFRHJIbVpHd3ExNTFIR2RiWnhjaEEzYmdQQkY3dmdUYkUxelkKem5ZQ2hNNEx4UWVvc1FPWTR4My8zUmFQcUtNNGNzSEJtNHRDNTB2RHhiZSs3bjBCOU1oS1BPTUt0NVcvdzFGc0pSNEhxWFNlbkl1OApXNDB0L3FzdEZqWW96b0IxWUQ1dzFWa2w4OTNXTlZjbDhFTHdhb3N0ZllwSGNMSDRScDl6YitLZE1hcFZPd2lXM21Kc1JiUHgwMEhrCkdpMitKcWQ5NHJsbWlxVzNHRnZoMTZ3aUhHUys4T0piNlozeFhETkYxanNwTm8xb3JzYjRzSDkzOGNJbVpMNlZXN2pSb3ViWDEyZVMKVnpzbWo2eCtiTWpCMjl0T29KUHlLN3BHTHRvWnFsQnM0cDRVOWlvUUhhbmh3RHRIYjA4ODJtcGVIbHhoRlRRaXRqU3ZObmN6Q3Mwagp1UERPc2U4VGI2a3FEYTRRNHlyOFhtOUNkaHFXN0xwUEI3SHpkZ0o1NTlLdUlNS0F4aDZTdUhtU0Q1M0pUb0YxMEcrTnZMTVlPNWVaCkwxSWJNT2FUNnMwT3lBUG5pWk1ZSi9iT2R6cm1pNWdVNFE5cXBHUVBZYUE3NU5kQmtCTU5YSW1WRFhuWEY5TjQ0NGVqZ1R3dmN2U3UKWXdNUkw0bVRia2JCWEhtcEFxdEpydXBNOXhBT1BHVzh2TjBxcjc2WVlUUHk3cE1jaDh5SThyWmVCK1liQmFkQWNDVlpmZkY2Q1NSegpHbnZPNlBPaUNQdmNLQTZ1eEV2aTROSVZac0dLMG5nem1SRk5ReUhCUWZrM2lsL0V5aFZjZVVhc05wTWFieVl6b3IxcjIzNzFqUU1ZCndIeXZhdmx1NnBBZTNYMlFsMklTNTREOTZ2dTJuY0RtSzU3YzdhQU1xZ3lwOFdibWNZaHZZN1kzcURnM0FzeFh2QlFGWmROSkFsM08KRytPTHZQYXBpdFI4RjhYT0VkSm9jd1RKRUU2Ry9UNHk2bXZsN0hNVnFma1dMb3BEOU0zeHJ4d2xiUStxR2pHUDFqYjFGam5DMlJ6UQpOMS9jUVBUTnlBZjlpcHg3VU5YWVlaK3R4TUh6UDBEZS9HWjlQTjlNRzFkRjlIeW9hdXl3cndQSHUvQVdnTHp6VEhpRnRXZnNsV0JYCm9JQkg4dHEvOTloYUxpSHp2VDZFVnk0T2ZGQ0RyQkY0SU4zazY4T1Zydll2UGg1WnU0ZjBQWVRQYUROVzlLNzVVTmVnTFZvbFdMLzUKT0ZLZFhaZnFXL2JsNitmVmFybk1GSnArL3VOcDliMDJXYTdmaUZQZUdLL2t0ZDlzRytlWm9IdE85WlVzQVMvZlQ4dHR5Wk10S3k2SApGS0Vhc01weDRrVk5Nc1crdUJGYjNuMlp2bUpldEY2VktadDl2Slc2ZjZFdWFDVDRVYlJLc1Y1K1A3ZlJ4eXhnZlhmZG82K3NqM2o3Ci90aHFQZUhIdDFMOWxHUkxJSUJmOHRyWEhPTGs5MllPNnB2a1I1dlV6ZjVvQ3ozRFpua0EvUHZxYTBwM3YyVWU0Sm04OWdmRXhZcjkKbmNMNkp2V3J1SVN5TG00TjJYejhSRkdDY2xHODlWV1UrYVA4MS9DTlB1Tk5HUGtscjcyK3U0ajFGdFkzUFZKbDgveWVDMnczWDFXUgowK2Z6VTA2ejBodEx2UWlyWXRwK2xKd1BXSjk0djF2MjdpVDYvc2QvRnIvaDQ1ZnkvYng1aVQ5a2dSYlJqakVJNytTMTF6ZGVmbWNMCmliNy85ZC9aYi9iNHBPa3RQdDh6Q3NQM3YzcWtyb2Z5MnVzYnYxKzR1aEZ4bDFZNHRycmFpZ3B2UkF2MlNWMGY1YlhYTjQ2RUh1WXkKZmVmcDdnWGpMdFhMNGViMDRoV21YcW5ycGJ6Vyt1NGlWN20rMDZ0a2dISmpITWk5SFdLejNFVy9mcW1iVGpwVFAwWUJXMzEzZVdlSgp2dnNiMUMzMkozNm5BbWR1RFBWTTNiUWpTUDBZUlI0dDg2T1hiZlFwWmZwZUp4NTZhZkdidEJjNDhRSnZ2cW1ieUV0ejZGRVp0dmU5ClZldWJobGhXMzJrdmNHVEEvbFF6OXZSODZlWUxXTlluRmZSTlF5eWJEZVJ2YWROKzg3TDdqbjdocjd5MnMrMjd0MzJ6S05GMyttZG4Kd0Y4MlMzMTZjZnAyUy8zQ0FEeVdkN0t4RzI3ZjZUc3IxWGVSZEJtc1Fybm5MZldia3VLenZKT3RuWU5Pdk9XZk1uMlRMb05kS1BmbQpUNUc1Z05meVRpWWZWbWIxc2d0OGZwZnBtMHk1VzdZeWZEVmd6K1cxdk53dmlXVWZyc3YwdllvWFlFdDlQLzJMbWlOOGwvZkhnRzFXCjRDUVRuZDJWNlp1TWNWaUc2dVJiRWlEOGxmZnJPY2twdDFZYkdKTEU1VjlwaHJRTHNDejFKVHdqUllxMzh2NW8rcFlheEtQTmkxOXYKNDgrNHVhclcxMGtweFNzOExVb21sclJPaTBKTGl6ZWZKcVpsQnJ6VDEzWlV4TDhGMkU5NTkrOTVYeFN5RWpqNWtMSVYySTIrM3BVbAp2WlEzKzVZLzkyTnNHM01YbldSSWs4dEZsYjYyclVqU3N6UkVmSlMzWUVQUCs4N3E0OG8waXQ0djQzSVB2ZFBYemFpSU41ejdKNi9vCkliOFBZNDBmaGliOGtwcVZQTVRhNld1OWVkOHJmZjJiMWdEWHY0ekEyeS90U3NkTGJ1ejFmLzVMbHYvRzlRM3JmZVErK1dmdjVKVkYKTnhtQkoxdkZyU0F4ejAvRnZYci8rYjh5ZmVPL3RqM213NmY0S3BFWCsxcDFPZktYdTg0VjdoOHJKODkvWHZUekttZEtqNnZremYrZgpSTis0L214OUE0NUgrclk5MjZWUXVyUityZ3FHdUh4Nlg4TmlyTDlYSDRWLy9CV2xWa21PSk9zeXhQMGo2M01Ddk5saWxKNTg1SXU4CmxWc0UxNGNSMUQzYjVmSnJkV0M1Qkt6bkk5MktrT1JJc2pHT09MeXlYbjU5MlNEbzJSWXlwYkJWWEV3clB6YTd6U1JwemtyR09IYW4KY0ZpZkUrQkwvVG1SOTVUNk9XS1VEN2Y2ZkZmZWxydDVFclRhYmEyV2pISGNhVDJJRkUvU0k1OE9YOUE3K3lnNkw2SDg0eDQvSk52cApkelVPaWI3eDhtdC9qSXNYNGRYUUoza05KaFkvMTZzbmNaUDE1bWN0L2k1eHNFa0lEdXM3ajd1LzF2dU12UWl2MHFOVHpxZ2ZaR0paCkwzcFpweWo0MVczeUhXRjk0eU9nN1UvWm9ya1hNazhxcndjTlgvdHpjWlIvRmZiZkU5WTNkcy8ydDJkNU1GOTM0WSs4SkhkaGcwZU0KeHBkTDJ2KzJrWjhIZXpoMGtINFhDdUk1dkZtekF2UGZ1SGhsSDEzUnUrZjlYUm5VRDRMbm1ndDNZWVAxcTdpNFlYOUNQSGx6b2V1TAp2QTR1aWxTbFlGVFFLU3R4ZEdWL3dRTjU5THcvcnB1NHA0QjRESzlRY1lBYXdQSG1Na2NYUEJDeWw1ZTRLa2w1RnpZVVhzWFhsem00Cm44V1hxekpvcTVLMGQyRkRoNXpGeVpHajY1WG8yTXZML1pvcWRZQjA5SzQyODZXOTZlWndnUy9wZWQzVWQyRkQ3cmtKNW51NGhZeTAKcmtGK0Z6YmduaGZSbnp1NjNKQ0svbDdlRWVGVGVIQVhOaEE5UjllbmJPMi9INlg1SG00QS9VWDRGSmhocytSdEE5ZVh4WTFmQjVjZQpFWnJ2K1VGZXVzVFhpN3V3Z1MzOE4yNmVqZEI4RDdkdkV5YStYdHlGRFpodmZMV3pmVmhBMkZrNHFFdVhHWGx5Rjdab3ZuRnU1T0RhCkk3SjkzY09NdkdRTmZVL3V3Z2JNTjZwTU92amwrMVIrRlk0WlpPUWx5NHg4dVF0YnJHM0VmVUg3dSsvSXhxNzZHWG1wTG9uRURLeEsKTHdZRHJqK0sydm9PdkROVmNIV1drWmZxQmwvTXU3REx6VWpNZmFQS2xRUHYvRWJ6WnJPQk0xbm9qTmpHcjdBaXNiRWZwNzRPdkRQUgoxRlVuS3kvTlJXUSszWVV0bkg0MWovN1VRZWhINDUyemdUTlY2SXpvbXlzM0RvaHpHMUhzN0NBNG9QSE9nNXk4TktFelh0eGNmZUdxCm1CdkYxeDQ1V0Q1SVl1ZCtUdDVmRkkrQU40U2pNamdoVEQwdm9qOTFVRlVqR2NycDV1V2xxRHJqM1lXdFVqdjZCNlpHRGhaZmtxdWEKVzNsNUx3Z2VBYTNlclBTQ2IrcGFmRjlWdnJ0cjh1cVNWSjJ4MGlMRnV2NDF1UGc2K1A0RUU4K0RncndFc1JYYTBxdjRlb1dMbmVPQgpad2VaTDhIaVc0aXNLR0lyckRrTjFiY3JEdVZFZitvZ2VTTllmTHRGZWZGaks2UzlDY3FiZldhQ3ZORjJGQWZ4SDBIbTJ5cktpei9yCmpET0dvM0VRcjVBYXVZcXQwRWR5aGtWMUNZWmhVZFRWT1daS2FPcEhJeHNPQnVyd1k2dUJJQy82TGxDVVFRMnRROFNFekRmdUtqaDQKQ3ZUWXFpZklpOTRUUk9uMWFwMVJJelI5NDlEWndScnlydk1VTG1pTDhtSVhOakJxVnBvbkVJR2hzd041MFVOblVWMzBwaEhDbUpYdQorVkp6U0Y0SHo0bDlUdDBBa0JkNzhhMi9HNmg5ZXBnd3NoRmxSaTUrRFpGZkxiRDBvaSsrdGVkRittZkRDUU4xMFY0VUY0c0k3cHVGCmxsNzB4YmRtZVUxdVM3NkY1SFVSQWlLM2ZDRjFzUmZmZWhzS1JzY3FDL0wrbTdpUkZ6ZnhIWUR5SWkrK3RhcjdZbVF2d2p4ZFZOZmcKSnkrNDlQNzZOVVo5aURyVlRTNGYwK1d5R2ZLMllIbHh5ODQxcW10YVJnRGxaZGZ4SGNMcUlwZWRheFBYL0w3a1pzaDdJWkVYZHl0SwpYZXF1emZzenpaQzNLNUVYdCtkYms3bzJPeTZiSWU5SUppOXFhbFNMdUJhbU8ybUl2Q2N5ZFhGVG94cktHbStXbTZWQmVSMDBmRDh4CisvazlxYnk0cWRHWDYwMEszMXZMSjZvbk1YcGIyVDZYRmkyNXZMZzd5YllybDVXcnRYM2xyNWF5eGpmdUtNNVlyaTc2T096V1dWZHcKN1dKNXE2RW9pU3d1TUFLYkJYMGI5Nk1UQzNZaWJnMHRCWFJ4YzhkWlVSZXVZcmJHMXk3dlg2S3J3QlJzQ0JvN21MZDNna1BMaG1YcQovanJIZjZCSmNuK2pJY1diSXgrdUxvMmZ3MlU3L3dXNDd4Q0IwMUo1cVE3Wk1MMDUvYnRRZ0p6OTJabWNHZUF3anNtMC9kczcxWUU0CjUrWHkwcDNjdlhuWFZQanR1V2dnczl0NVdvc3dZZ3JKcS8xY245OTBseGlWKzJZcTc1encrUFNzR21pOXZBdnZjQ2R1Y2lLVkNmQWcKck41enJaOUk3dytzOE0zWVRWK1J6ZE56bGJXc1Y4QVZvS200NlMzcEJnaHA3NTNXYzMwV3J2dW1vRjBsTDgwWk9RV1dYNnMxRUc1OQpycjlYU3pBY1BZaWJ1RlFUaEIyZ2dwdi9lYTVuNEo3Q2RYUlg1WmI2cFUzS2F4bzc2SzhrTzdCZFJxeFdYOUgvbERpOW05dGNVR1FhClc0RmJ5RUNXR2JiVWJ5bER2MUplY3Urc3pVMXg2OWMvd3c4U0lxc0g2aDlObDFhMXZENWM5NnFGVUd1Nk0vc2NlUHMySjA2cTFTVzkKV01FSVFaYTUyZWZBaHk5dzRreEJYcEpEY213UWo3UXhXM3lGcGRjOGdTYWlveUl2NmExR0pzQkgydWdDSDN6RWljcWtkd2RSWWRJWQpZVmY5dGNtbndNZVdjZUpjVFY0dlVsOE54TU42VFVKZStOQkJSbFFudlR5REs4bHBud1FmUWtwUFVWN3FDMSsxRVF6UHdEdUx2dG04CjgwVERTRlZlYnNIVnZRTnA0T082R2FFWVdFVXdxMXc5Q1BKcWQ0MHU3VCtDbU1wdXdnSGFDMzMxRVV3dnZpUk9CL0dtRzJacGtXcGcKRlVGMThZMHBvbmZXTEVtSWdSVTMzOXpWa0pmNHVuVnRSTzg4MTB0YXhWdm1tUG5tb1ZMRktzV250cUFLMTNibUMxd3l4eXh1VnM2SwpkakRMalc3dHpGZHlSU1FqbExPaUhhUXpWL3JJcm1nMS9tclRuakVSR2xuUkRtYTUwWjJOK1FMWE16T3JOeXYwOGZNd0syMWNXcGl2CkdKaHhDNndHdXVxeU0xOHh1RkxPZmEvTXY5UVRORW9hS2N4S0cyTGJTSFhhNHEveFYvcUNnZkgrNmpCcit3TG0rMXZsNjJaejhRdVoKWlVXS2pkNm1tYTlTZEhYUDNuaDE2cEdOTWwrRm1VbkFOWE16WHExNlpKUE10enA5aFZ6elVSaHZJOHkzY2l3SGlKcVB4SGpabVMvawpaNi9MbDk5YjRFdVk1YnlteHN2UGZDRlRMRjErb1YrSU9iT2MxeWhzWm1tK1FQbXBkQ0x1QVZoNHVRMnZtK1M4ZS9ObFZycTZoL1NWClpyOHphTEcrWmxadE5paFlIV0JXZVFZRmsrazdXMEQvbUZsY1pXTzh2OWhWbmk4aHhlRHdHVmFYMjNDemxmR3k2L3ZDN25rTzZBdXIKeTgwMWEvZDVpekFiMjREZHM2Z3ZyQzQzMTZ3N3BDRkNjT3U2RmJCN25oZldYNG02M0Z5ejVvUVZCTE9oU2JCU1VZeXZKT291cUo5ZApFNzN4U0pnUnM5b0dXTnpJV3lhWTcvSXJhS2p0eHErQ1dXMURzdnhPcDNkcDJQUWJWcGZidmdTTGNtUVdiclVObVhGT0Y3c0E2eDcrClcyN2xLdXVrS0lWYmNnUzJCdE1BNjJZaCtVdG1uUVQ1ZlVYYU1FdU9vTTI2cVlQK0o3RnNkbUhWWkdpZEZLVncyNjRQVGk2WHMyQlcKejNDU0ZLVndpNjYwOWVWV3JYSVZWKzFnRjExcDZqdG5kN3lncTdocUI3ZmExVVNhL2paRVhldGljeDV1UjlWTk5PeVhvYm91NmxVNQo5OHl0ZGpWUjFuZkJUMTJiQ1J3WWRnZkZUaFQxNVJjeld6ZnhJZGdsdnhOcGV5SExGVU4xM2FXOEI5aTFGaUprNWVVOTdHcFZFVTVhCkNVMXd6OUw2YzRMU0pqUGZxTUUxYzNYUGsxbEpnc1F3Wko3VTQ1clp1dWVTQlpqanNqdXB5VFZITUJ1TFRibUVIVFN6MDFGU25EV0sKUkJnV055Sm00c0VxTExQZENOY0ZqU3djaXhzeGY0c0d6SzUzbitLOG9KR0ZZZTE1eHl4WDRyaGlhcnBLRjFIWndPMGcvZ09YK3pHTgpPY3QwS09ha1J0Y2NjMEw5RTVxVFRHcmM4Z3lZSTRiYXg1UHB3alE3aW9rdWt2ekRiZG8xUzIwNTBRRjJnM1ZaWm13WDNZZ2FjNklECmZKZGY1b3pyWG5oM01GNStPVlAvd3J1RDgvTExHT01UY0hSaHZmeHl4ZkYwVlJuOEJtUFpvM0kzcnpPWUZwLzVVbGNYRUtZVHdpdGMKbkk0MVY5TUs0UlVtYUdGVkN0dm1Ba2NRdzZvVWxxTlhQRUVOcTFLNEhickJsdHJiUkRBc1IrdjRnVld0S2hMQ1p4U0kxQTNWU1JUUQpnK1lESVQycUhZUVdyNXlRSHRVTVFVcVVoZW5vTXhlSTFRMzYxZ3BSU3BRbHBMKzE0WUc2UWQvYThFTGRvRzlOMUxuZEpPaExEVld4CkNpQ1VyNXpqa2JxaFBPa2NuOVFOK3JyR0wzV0R2bTd4VGQyZ3IwdjhVemZvNnc0ZjFmM1JOK1JIVHZCVDNWOGgvM1dDdCtvR2ZSM2cKU1NVeTZGc0xYcXNieG1NdDhWemQwUCsxNHRSM2RYLzBEZk5YcHBEUFpxZ1E1dXNNSVoyYTA5QTNGRGhNSUp4NDFTTVVzUFR4T04wVgpDUW1TSmllYzFBM0hNMmppZlVKVUpBVFFHckFJbWZPMCtGMU1Sd1dib0NwTEoyd1FWV0tJZkc2R004THhoQXFjb0o1NTQ1U3dBRmZDCm9BNHBKMVE0eWhteVhIWVBkTUlCWnlXTWVXVzdFS0ZGS09XQ3MyTk9DUmtTekpCSkM2R0tNR01Id2F3TVdjWjVpS0NMOUp2Z21GTkcKb2NTUlkxanJiVk1FaEI1RGhrYkVWSGxDQ3B6U2xKaXFRRERnbUFIZkttUTV3WUFiYTdvN2p0NkFHMnU2TzFwSEhVSTNMbUFXT1R2ZQpISmgxZDBpVlkrMHlqTG0yN1hWcEgyRVZldGlqZnV1STlJN05RMTgwTzZRcU1qcXFOc1BSK09VRDdhT0pvUnVkNnNycEhzY1MzRHVHCmVCbWljd1JMOE9seExib0ZnUnMrS3pzNHZrVTNUNU5qcktNWE42S3BBbytiWDRGVW80a0NqNWxQTUR1bGFRSUhjUXMwU2VCQmNNc2kKbzlObXBFa2hvSkxRaER6NHREbmp5elhBdTVJMTdCMXpFVU9KTnR0MjhMaDdyT1ZITFVZc2ZmUnBXSEtWNlRKcko0MkRWOVpqMU9kagp3cWNoRVRMZ25NVXFmSElXVmx4RE9sM1BCOS9IL1pBSFdURTY4MWJoWVlpbVhORHFlNmp3TUN5NDd2RE1oc2Y5b0sxalJsMVBJcTJUClhsaHY2K0c4VDF5ekhGNTBRNEpiSno5R1RKVVFENExab3RBNlE1ZDQwQXRSTWlhdHMxTWtSejBNMHRMUU9lOE42alhqUWI4YkhESXAKby9QZVJRMTJQQXpLZWtTNzJ4czRTbzEvaEQxcmh6cXloNHphWjcyQnNiOCtHZlI3NTJHWjlaOVcrN3pYT3gybzJQTndNTGpvOWJydApJQ3RQUnUySXMxNmU4K2dQdzlvYUNBUjg1ZjhCTDA3Z240bUpHTlFBQUFBbGRFVllkR1JoZEdVNlkzSmxZWFJsQURJd01qRXRNRFF0Ck1EZFVNakU2TlRRNk5URXJNRE02TURDM1EweUxBQUFBSlhSRldIUmtZWFJsT20xdlpHbG1lUUF5TURJeExUQTBMVEEzVkRJeE9qVTAKT2pVeEt6QXpPakF3eGg3ME53QUFBQmwwUlZoMFUyOW1kSGRoY21VQVFXUnZZbVVnU1cxaFoyVlNaV0ZrZVhISlpUd0FBQUFBU1VWTwpSSzVDWUlJPSIgLz4KPC9zdmc+Cg==';
    $icon_data_uri = 'data:image/svg+xml;base64,' . $icon_base64;
    // Main menu
    add_menu_page(
      'Pay with seeds', // Title page
      'Pay with seeds', // Title menu
      'manage_options', // Role allowed
      plugin_dir_path(__FILE__).'admin/configs/pay-seeds-config.php', // Slug
      null, // Function to render
    //   plugin_dir_url(__FILE__).'admin/img/icon-pay.png',
      $icon_data_uri,
      '2'
    );
}

// Import Css
function import_js_to_pay_with_seeds ($hook) {
    // if (str_contains($hook, 'admin/configs/pay-seeds-config.php')) {
    if (strpos($hook, 'admin/configs/pay-seeds-config.php') !== false) {
        wp_enqueue_script('VueJs','https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js'); 
        wp_enqueue_script('BootsrapJS',plugins_url('includes/bootstrap-4.6.0-dist/js/bootstrap.bundle.min.js', __FILE__));
        wp_enqueue_script('Toast',plugins_url('includes/js-toast-master/toast.min.js', __FILE__));
    } 
}

// global styles
function add_stylesheet_to_head_pay_with_seeds() {
    echo "<link href='".plugins_url('public/css/button-positions.css', __FILE__)."' rel='stylesheet' type='text/css'>";
}

function import_css_to_pay_with_seeds ($hook) {
    if (strpos($hook, 'admin/configs/pay-seeds-config.php') !== false) {
        wp_enqueue_style('BootsrapCSS',plugins_url('includes/bootstrap-4.6.0-dist/css/bootstrap.css', __FILE__));
        wp_enqueue_style('BootsrapCSS2',plugins_url('includes/bootstrap-4.6.0-dist/css/bootstrap-grid.css', __FILE__));
        wp_enqueue_style('Main',plugins_url('admin/configs/css/main.css', __FILE__));
    }
}

function renderShortPayWithSeeds ($attrs) {
    // var_dump($attrs);
    $id = $attrs['id'] ?: '1';
    $pk = $attrs['pk'] ?: 'Testing';
    $btnStyle = $attrs['btnstyle'] ?: 'light';
    $multiStepStyle = $attrs['multistepstyle'] ?: 'light';
    $accountName = $attrs['accountname'] ?: 'light';
    $amount = $attrs['amount'] ?: 'light';
    $email = $attrs['email'] ?: 'light';
    $imageUrl = $attrs['productimage'] ?: 'light';
    $productName = $attrs['productname'] ?: 'light';
    $productDescription = $attrs['productdescription'] ?: 'light';
    $urlCallback = $attrs['urlcallback'] ?: 'light';
    $buttonPosition = $attrs['buttonposition'] ?: 'left';
    
    // wp_enqueue_style('seeds_pay_css','https://seeds-cdn.s3.amazonaws.com/js/paywithseeds.js');
    // wp_enqueue_script('seeds_pay_js','https://seeds-cdn.s3.amazonaws.com/js/paywithseeds.js');
    wp_enqueue_script('seeds_pay_qrcode_js','https://seeds-cdn.s3.amazonaws.com/js/paywithseeds.js', array('jquery'), NULL, true);
    $shortPayWithSeeds = new ShortcodePayWithSeeds($id, $accountName, $btnStyle, $multiStepStyle, $buttonPosition, $amount, $email, $imageUrl, $productName, $productDescription, $urlCallback);
    return $shortPayWithSeeds->render();
}

// Add global styles
add_action( 'wp_head', 'add_stylesheet_to_head_pay_with_seeds' );

//Import js
add_action('admin_enqueue_scripts','import_js_to_pay_with_seeds');

//Import css
add_action('admin_enqueue_scripts','import_css_to_pay_with_seeds');

//Add shortcode
add_shortcode('shortPayWithSeeds', 'renderShortPayWithSeeds');

//Add custom endpoint

/**
 * Grab latest post title by an author!
 *
 * @param array $data Options for the function.
 * @return string|null Post title for the latest, * or null if none.
 */
function my_awesome_func(WP_REST_Request $request ) {
    global $wpdb;
    $posts = $request->get_json_params();
    
    // Validate post params
    if ( empty( $posts ) ) {
      return null; 
    } 
    
    $transaction = $posts;
    // return $transaction;

    if (!$transaction['from']) {
        $response['status_message'] = 'Missing from field.';
        $response['status_code'] = 201;
        return $response;
    } else if (!$transaction['to']) {
        $response['status_message'] = 'Missing to field.';
        $response['status_code'] = 201;
        return $response;
    } else if (!$transaction['quantity']) {
        $response['status_message'] = 'Missing quantity field.';
        $response['status_code'] = 201;
        return $response;
    } else if (!$transaction['memo']) {
        $response['status_message'] = 'Missing memo field.';
        $response['status_code'] = 201;
        return $response;
    }
    else if (!$transaction['product_name']) {
        $response['status_message'] = 'Missing product_name field.';
        $response['status_code'] = 201;
        return $response;
    }
    
    $SQL_INSERT_TRANSACTION = "INSERT INTO `{$wpdb->prefix}seeds_pay_purchases_list` (`data`) values ('".json_encode($transaction)."')";

    // echo $SQL_INSERT_TRANSACTION;

    $result = $wpdb->query($SQL_INSERT_TRANSACTION);
    if ($result) {
        $response['status_message'] = 'Transaction saved successfully';
        $response['status_code'] = 200;
        return $response;
    } else {
        $response['status_message'] = 'Ocurred a problem trying to save the transaction';
        $response['status_code'] = 405;
        return $response;
    }
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'paywithseeds/v1', '/purchases', array(
        'methods' => 'POST',
        'callback' => 'my_awesome_func',
    ));
});