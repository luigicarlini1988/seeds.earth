<?php
/*
Plugin Name: Pay With Seeds
Plugin URI: https://joinseeds.earth/pay-with-seeds
Description: Pay through seeds
Version: 0.1.7
*/

//Import class
require_once dirname(__FILE__)."/public/shortcodes/ShortcodePayWithSeeds.php";

require_once dirname(__FILE__)."/admin/configs/svgIcon.php";

function ActivatePayWithSeedsPlugin() {
    // echo 'Activate';
    global $wpdb;

    $SQL = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}seeds_pay_config
    (
    `id` INT NOT NULL ,
    `style_btn` VARCHAR(100) NOT NULL,
    `style_theme` VARCHAR(100) NOT NULL,
    `button_position` VARCHAR(100) NOT NULL,
    `data` JSON,
    PRIMARY KEY (`id`)
    ) ENGINE = InnoDB COMMENT = 'Seeds Plugin (Pay with seeds)';";

    $SQL2 = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}seeds_pay_purchases_list
    (
    `id` INT NOT NULL AUTO_INCREMENT ,
    `date` TIMESTAMP NOT NULL ,
    `data` JSON NOT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE = InnoDB COMMENT = 'Seeds Plugin (Purchases list from pay with seeds)';";

    // - Date/time
    // - SEEDS Account Name
    // - Amount (in Seeds)
    // - Memo
    $wpdb->query($SQL);
    // $wpdb->query("DROP table {$wpdb->prefix} seeds_pay_purchases_list");
    $wpdb->query($SQL2);
}

// function Desactivate () {
// }

register_activation_hook(__FILE__,'ActivatePayWithSeedsPlugin');
// register_deactivation_hook(__FILE__,'Desactivate');

#Add menu
add_action('admin_menu','create_menu_to_pay_with_seeds');

function create_menu_to_pay_with_seeds () {
    $icon_data_uri = 'data:image/svg+xml;base64,' . getIcon();
    // Main menu
    add_menu_page(
      'Pay with seeds', // Title page
      'Pay with seeds', // Title menu
      'manage_options', // Role allowed
      plugin_dir_path(__FILE__).'admin/configs/pay-seeds-config.php', // Slug
      null, // Function to render
    //   plugin_dir_url(__FILE__).'admin/img/icon-pay.png',
      $icon_data_uri,
      '2'
    );
}

// Import Css
function import_js_to_pay_with_seeds ($hook) {
    // if (str_contains($hook, 'admin/configs/pay-seeds-config.php')) {
    if (strpos($hook, 'admin/configs/pay-seeds-config.php') !== false) {
        wp_enqueue_script('VueJs','https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js'); 
        wp_enqueue_script('BootsrapJS',plugins_url('includes/bootstrap-4.6.0-dist/js/bootstrap.bundle.min.js', __FILE__));
        wp_enqueue_script('Toast',plugins_url('includes/js-toast-master/toast.min.js', __FILE__));
    } 
}

// global styles
function add_stylesheet_to_head_pay_with_seeds() {
    echo "<link href='".plugins_url('public/css/button-positions.css', __FILE__)."' rel='stylesheet' type='text/css'>";
}

function import_css_to_pay_with_seeds ($hook) {
    if (strpos($hook, 'admin/configs/pay-seeds-config.php') !== false) {
        wp_enqueue_style('BootsrapCSS',plugins_url('includes/bootstrap-4.6.0-dist/css/bootstrap.css', __FILE__));
        wp_enqueue_style('BootsrapCSS2',plugins_url('includes/bootstrap-4.6.0-dist/css/bootstrap-grid.css', __FILE__));
        wp_enqueue_style('Main',plugins_url('admin/configs/css/main.css', __FILE__));
    }
}

function renderShortPayWithSeeds ($attrs) {
    // var_dump($attrs);
    $id = $attrs['id'] ?: '1';
    $btnStyle = $attrs['btnstyle'] ?: 'light';
    $multiStepStyle = $attrs['multistepstyle'] ?: 'light';
    $accountName = $attrs['accountname'] ?: '';
    $amount = $attrs['amount'] ?: '';
    $amountInSeeds = $attrs['amountinseeds'] ?: '';
    $amountCurrency = $attrs['amountcurrency'] ?: '';
    $email = $attrs['email'] ?: '';
    $imageUrl = $attrs['productimage'] ?: '';
    $productName = $attrs['productname'] ?: '';
    $productDescription = $attrs['productdescription'] ?: '';
    $urlCallback = $attrs['callback'] ?: '';
    $buttonPosition = $attrs['buttonposition'] ?: 'left';
    
    // wp_enqueue_style('seeds_pay_css','https://seeds-cdn.s3.amazonaws.com/js/paywithseeds.js');
    // wp_enqueue_script('seeds_pay_js','https://seeds-cdn.s3.amazonaws.com/js/paywithseeds.js');
    wp_enqueue_script('seeds_pay_qrcode_js','https://seeds-cdn.s3.amazonaws.com/js/paywithseeds.js', array('jquery'), NULL, true);
    $shortPayWithSeeds = new ShortcodePayWithSeeds($id, $accountName, $btnStyle, $multiStepStyle, $buttonPosition, $amount, $amountInSeeds, $amountCurrency,  $email, $imageUrl, $productName, $productDescription, $urlCallback);
    return $shortPayWithSeeds->render();
}

// Add global styles
add_action( 'wp_head', 'add_stylesheet_to_head_pay_with_seeds' );

//Import js
add_action('admin_enqueue_scripts','import_js_to_pay_with_seeds');

//Import css
add_action('admin_enqueue_scripts','import_css_to_pay_with_seeds');

//Add shortcode
add_shortcode('shortPayWithSeeds', 'renderShortPayWithSeeds');

//Add custom endpoint

/**
 * Grab latest post title by an author!
 *
 * @param array $data Options for the function.
 * @return string|null Post title for the latest, * or null if none.
 */
function post_purchase(WP_REST_Request $request ) {
    global $wpdb;
    $posts = $request->get_json_params();
    
    // Validate post params
    if ( empty( $posts ) ) {
      return null; 
    } 
    
    $transaction = $posts;
    // return $transaction;

    if (!$transaction['from']) {
        $response['status_message'] = 'Missing from field.';
        $response['status_code'] = 201;
        return $response;
    } else if (!$transaction['to']) {
        $response['status_message'] = 'Missing to field.';
        $response['status_code'] = 201;
        return $response;
    } else if (!$transaction['quantity']) {
        $response['status_message'] = 'Missing quantity field.';
        $response['status_code'] = 201;
        return $response;
    } else if (!$transaction['memo']) {
        $response['status_message'] = 'Missing memo field.';
        $response['status_code'] = 201;
        return $response;
    }
    else if (!$transaction['product_name']) {
        $response['status_message'] = 'Missing product_name field.';
        $response['status_code'] = 201;
        return $response;
    }
    
    $SQL_INSERT_TRANSACTION = "INSERT INTO `{$wpdb->prefix}seeds_pay_purchases_list` (`data`) values ('".json_encode($transaction)."')";

    // echo $SQL_INSERT_TRANSACTION;

    $result = $wpdb->query($SQL_INSERT_TRANSACTION);
    if ($result) {
        $response['status_message'] = 'Transaction saved successfully';
        $response['status_code'] = 200;
        return $response;
    } else {
        $response['status_message'] = 'Ocurred a problem trying to save the transaction';
        $response['status_code'] = 405;
        return $response;
    }
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'paywithseeds/v1', '/purchases', array(
        'methods' => 'POST',
        'callback' => 'post_purchase',
    ));
});