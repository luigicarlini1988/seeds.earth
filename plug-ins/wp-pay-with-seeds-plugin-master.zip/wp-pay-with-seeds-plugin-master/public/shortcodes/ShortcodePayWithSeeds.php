<?php
// require_once dirname(__FILE__)."../../admin/seeds/widgets/widgets-seeds/assets/js/widget/paywithseeds/paywithseeds.js";

class ShortcodePayWithSeeds {

    function __construct(string $id, string $accountName, string $btnStyle, string $multiStepStyle , string $buttonPosition  , float $amount, string $email, string $imageUrl, string $productName, string $productDescription, string $urlCallback)
    {
        $this->id = $id;
        $this->accountName = $accountName;
        $this->btnStyle = $btnStyle;
        $this->multiStepStyle = $multiStepStyle;
        $this->amount = $amount;
        $this->email = $email;
        $this->imageUrl = $imageUrl;
        $this->productName = $productName;
        $this->productDescription = $productDescription;
        $this->urlCallback = $urlCallback;
        $this->buttonPosition = $buttonPosition;
    }

    private function renderBtn() {
        $button = "<div>
            <button onclick=\"alert('$this->alert')\">PayWithSeeds!</button>
        </div>";
        return $button;
    }

    private function renderPayWithSeeds() {
        if ($this->buttonPosition === "right") {
            // <div id='pay-with-seeds_".$this->id."'></div>
            $html = "<div id='".$this->buttonPosition."' class='pay-seed-btn-bottom-right'><div id='pay-with-seeds_".$this->id."'></div></div>";
        } else {
            $html = "<div id=".$this->buttonPosition." class='pay-seed-btn-bottom-left'><div id='pay-with-seeds_".$this->id."'></div></div>";
        }

        $html.= "<script type=\"text/javascript\">
 
            render = function(id, pk, btnStyle, multistepStyle) {
                // console.log('Iniciando PayWithSeeds ' + id);
                // new PayWithSeeds('pay-with-seeds_".$this->id."', {'privatekey':'".$this->pk."','button_theme':'".$this->btnStyle."','multistep_theme':'".$this->multiStepStyle."'} );
            }
            
            loadScript = function (url) {
                return new Promise((resolve, reject) => {
                    setTimeout(function () { resolve() }, 400);
                    var script = document.createElement('script');
                    script.onload = function () {
                        resolve();
                    };
                    script.src = url;
                    document.head.appendChild(script);
                    
                });
            }
            
            loadScript('https://seeds-cdn.s3.amazonaws.com/js/paywithseeds.js').then(() => {
                // console.log('origin loaded: pay-with-seeds_".$this->imageUrl."', '".$this->multiStepStyle."');
                // render('".$this->id."','".$this->pk."','".$this->btnStyle."','".$this->multiStepStyle."');
                try {
                    new PayWithSeeds('pay-with-seeds_".$this->id."', {'account_name':'".$this->accountName."','button_theme':'".$this->btnStyle."','multistep_theme':'".$this->multiStepStyle."','amount':'".$this->amount."','email':'".$this->email."','product_image':'".$this->imageUrl."','product_name':'".$this->productName."','product_description':'".$this->productDescription."','callback':'".$this->urlCallback."'} );
                } catch (e) {
                    console.error('Retrying')
                    setTimeout( function () {
                        loadScript('https://seeds-cdn.s3.amazonaws.com/js/paywithseeds.js').then(() => {
                            try {
                                new PayWithSeeds('pay-with-seeds_".$this->id."', {'account_name':'".$this->accountName."','button_theme':'".$this->btnStyle."','multistep_theme':'".$this->multiStepStyle."','amount':'".$this->amount."','email':'".$this->email."','product_image':'".$this->imageUrl."','product_name':'".$this->productName."','product_description':'".$this->productDescription."','callback':'".$this->urlCallback."'} );
                            } catch (e) {
                                console.error('button not rendered')
                            }
                        })
                    }, 2000)
                }
            })

        </script>";
        return $html;
    }

    private function renderTitle() {
        $title = "<div>
        <p>$this->id</p>
        <p>$this->pk</p>
        <p>$this->btnStyle</p>
        <p>$this->multiStepStyle</p>
        </div>";
        return $title;
    }

    public function render () {
        $html = "";
        // $html .= $this->renderTitle();
        $html .= $this->renderPayWithSeeds();
        return $html;
    }
}