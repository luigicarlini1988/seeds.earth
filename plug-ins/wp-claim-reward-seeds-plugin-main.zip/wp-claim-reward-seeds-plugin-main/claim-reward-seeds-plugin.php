<?php
/*
Plugin Name: Claim Reward Seeds
Plugin URI: http://localhost
Description: Claim Reward Seeds
Version: 0.1.0
*/

//Import class
require_once dirname(__FILE__)."/public/shortcodes/ShortcodeClaimRewardSeeds.php";

function ActivateClaimRewardSeeds() {
    // echo 'Activate';
    global $wpdb;

    $SQL = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}seeds_claim_reward_config
    (
    `id` INT NOT NULL,
    `org_id` VARCHAR(100) NOT NULL,
    `campaign_name` VARCHAR(100) NOT NULL,
    `style_btn` VARCHAR(100) NOT NULL,
    `style_theme` VARCHAR(100) NOT NULL,
    `button_position` VARCHAR(100) NOT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE = InnoDB COMMENT = 'Seeds Plugin (Claim Reward Seeds)';";

    $wpdb->query($SQL);
}

register_activation_hook(__FILE__,'ActivateClaimRewardSeeds');
// register_deactivation_hook(__FILE__,'Desactivate');

#Add menu
add_action('admin_menu','create_menu_claim_reward_seeds');

function create_menu_claim_reward_seeds () {
    // Main menu
    add_menu_page(
      'Claim Reward Seeds', // Title page
      'Claim Reward Seeds', // Title menu
      'manage_options', // Role allowed
      plugin_dir_path(__FILE__).'admin/configs/claim-reward-seeds-config.php', // Slug
      null, // Function to render
      plugin_dir_url(__FILE__).'admin/img/icon.png',
      '2'
    );
}

// Import Css
function import_js_claim_reward_seeds ($hook) {
    //Admin
    if (str_contains($hook, 'admin/configs/claim-reward-seeds-config.php')) {
        wp_enqueue_script('VueJs','https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js'); 
        wp_enqueue_script('BootsrapJS',plugins_url('includes/bootstrap-4.6.0-dist/js/bootstrap.bundle.min.js', __FILE__));
        wp_enqueue_script('Toast',plugins_url('includes/js-toast-master/toast.min.js', __FILE__));
    }  
}

// global styles
function add_stylesheet_to_head_claim_seeds() {
    echo "<link href='".plugins_url('public/css/button-positions.css', __FILE__)."' rel='stylesheet' type='text/css'>";
}

function import_css_claim_seeds ($hook) {
    
    if (str_contains($hook, 'admin/configs/claim-reward-seeds-config.php')) {
        wp_enqueue_style('BootsrapCSS',plugins_url('includes/bootstrap-4.6.0-dist/css/bootstrap.css', __FILE__));
        wp_enqueue_style('BootsrapCSS2',plugins_url('includes/bootstrap-4.6.0-dist/css/bootstrap-grid.css', __FILE__));
        wp_enqueue_style('Main',plugins_url('admin/configs/css/main.css', __FILE__));
    }
}

function renderClaimRewardSeeds ($attrs) {
    // var_dump($attrs);
    $id = $attrs['id'] ?: '1';
    $org_id = $attrs['org_id'] ?: 'Testing';
    $campaign_name = $attrs['campaign_name'] ?: 'Testing';
    $btnStyle = $attrs['btnstyle'] ?: 'light';
    $multiStepStyle = $attrs['multistepstyle'] ?: 'light';

    $shortClaimSeeds = new ShortcodeClaimRewardSeeds($id, $org_id, $campaign_name, $btnStyle, $multiStepStyle);
    return $shortClaimSeeds->render();
}

// Add global styles
add_action( 'wp_head', 'add_stylesheet_to_head_claim_seeds' );

//Import js
add_action('admin_enqueue_scripts','import_js_claim_reward_seeds');

//Import css
add_action('admin_enqueue_scripts','import_css_claim_seeds');

//Add shortcode
add_shortcode('shortClaimRewardSeeds', 'renderClaimRewardSeeds');