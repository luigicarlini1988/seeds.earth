<!DOCTYPE html>
<html>
<header>
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
</header>

<body>
    <div id="app" class="content-main">
        <div class="header fixed-top">
            <div class="d-flex justify-content-center">
                <div class="outer-wrapper">
                    <div class="frame">
                        <img src="<?php echo plugins_url('../img/claim-reward.svg', __FILE__ ); ?>" class="logo" alt="logo">
                    </div>
                </div>
            </div>
            <div class="language-container">
                <div class="dropdown">
                    <button class="btn btn-sm btn-secondary dropdown-toggle btn-language" type="button" id="dropdownMenuButton" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        {{ labelLanguage }}
                    </button>
                    <div class="dropdown-menu" aria-labelledby="dropdownMenuButton" v-if="translates">
                        <div v-if="translates && translates.languages" v-for="(language, index) in translates.languages">
                            <a v-if="selectedLanguage.key === language.key" class="dropdown-item active"  @click="setPreferredLanguage(language)">{{language.label}}</a>
                            <a v-else class="dropdown-item" @click="setPreferredLanguage(language)">{{language.label}}</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
                <?php
                    if(isset($_POST['SaveClaimRewardSeedsConfig'])){ //check if form was submitted
                        $org_id = $_POST['orgIdInput'];
                        $campaign_name = $_POST['campaignNameInput'];
                        $style_btn = $_POST['styleBtnInput'];
                        $style_theme = $_POST['styleThemeInput'];
                        $button_position = $_POST['buttonPositionInput'];
                        if (
                            $wpdb->query(
                                "INSERT into {$wpdb->prefix}seeds_claim_reward_config
                                (id, org_id, campaign_name,style_btn, style_theme, button_position)
                                values (1, '".$org_id."','".$campaign_name."' , '".$style_btn."', '".$style_theme."', '".$button_position."')
                                ON DUPLICATE KEY UPDATE
                                org_id = '".$org_id."',
                                campaign_name = '".$campaign_name."',
                                style_btn = '".$style_btn."',
                                style_theme= '".$style_theme."',
                                button_position= '".$button_position."';"
                            )
                        ) {
                            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ language.configuration_updated }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>';
                        } else {
                            echo '<div class="alert alert-success alert-dismissible fade show" role="alert">
                            {{ language.configuration_saved }}
                            <button type="button" class="close" data-dismiss="alert" aria-label="Close">
                              <span aria-hidden="true">&times;</span>
                            </button>
                          </div>';
                        }
                    }  
                ?>
            <!-- <ul class="nav nav-tabs mt-3" id="myTab" role="tablist">
                <li class="nav-item" role="presentation">
                    <a class="nav-link active" id="config-tab" data-toggle="tab" href="#config" role="tab"
                        aria-controls="config" aria-selected="true">Configuration</a>
                </li>
                <li class="nav-item" role="presentation">
                    <a class="nav-link" id="othervoice-tab" data-toggle="tab" href="#othervoice" role="tab"
                        aria-controls="othervoice" aria-selected="false">Othervoice</a>
                </li>
            </ul> -->
            <!-- <div class="tab-content" id="myTabContent">
                <div class="tab-pane fade show active" id="config" role="tabpanel" aria-labelledby="config-tab"> -->
                    <div class="custom-card">
                        <div class="row">
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="orgIdInput">
                                    <p><strong>{{ language.organization_name }}</strong></p>
                                    </label>
                                    <input v-model="orgId" type="text" class="form-control custom-input" id="orgIdInput"
                                        aria-describedby="Organisation Id">
                                    <small id="orgIdHelp" class="form-text text-muted ml-2">{{ language.organization_name_help }}</small>
                                    <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
                                </div>
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label for="campaignNameInput">
                                        <p><strong>{{ language.invite_campaign_name }}</strong></p>
                                    </label>
                                    <input v-model="campaignName" type="text" class="form-control custom-input"
                                        id="campaignNameInput" aria-describedby="Campaign Name">
                                    <small id="campaignNameHelp" class="form-text text-muted ml-2">{{ language.invite_campaign_name_help }}</small>
                                    <!-- <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small> -->
                                </div>
                            </div>
                        </div>
                        <p><strong>{{ language.choose_btn }}</strong></p>
                        <div class="row p-3 justify-content-center">
                            <div class="col-lg-3 col-md-4 text-center p-3">
                                <div class="row align-items-center">
                                    <div class="col-2">
                                        <input class="form-check-input" type="radio" name="radioStyleBtn"
                                            id="radioStyleBtnDark" v-model="styleBtn" value="dark">
                                    </div>
                                    <div class="col-8">
                                        <img class="btnImage"
                                            src="<?php echo plugins_url('../img/claim-dark.svg', __FILE__ ); ?>"
                                            @click="styleBtn='dark'">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4 text-center p-3">
                                <div class="row align-items-center">
                                    <div class="col-2">
                                        <input class="form-check-input" type="radio" name="radioStyleBtn"
                                            id="radioStyleBtnLight" v-model="styleBtn" value="light">
                                    </div>
                                    <div class="col-8">
                                        <img class="btnImage"
                                            src="<?php echo plugins_url('../img/claim-light.svg', __FILE__ ); ?>"
                                            @click="styleBtn='light'">
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-3 col-md-4 text-center p-3">
                                <div class="row align-items-center">
                                    <div class="col-2">
                                        <input class="form-check-input" type="radio" name="radioStyleBtn"
                                            id="radioStyleBtnWhite" v-model="styleBtn" value="white">
                                    </div>
                                    <div class="col-8">
                                        <img class="btnImage"
                                            src="<?php echo plugins_url('../img/claim-white.svg', __FILE__ ); ?>"
                                            @click="styleBtn='white'">
                                    </div>
                                </div>
                            </div>
                        </div>
                        <p><strong>{{ language.choose_multistep }}</strong></p>
                        <div class="row justify-content-center p-3">
                            <div class="col-md-6 text-center p-3">
                                <input type="radio" name="radioStyleTheme" id="radioStyleThemeDark" v-model="styleTheme"
                                    value="dark">
                                <img class="themeImage"
                                    :src="darkThemeImage"
                                    @click="styleTheme='dark'">
                            </div>
                            <div class="col-md-6 text-center p-3">
                                <input type="radio" name="radioStyleTheme" id="radioStyleThemeLight"
                                    v-model="styleTheme" value="light">
                                <img class="themeImage"
                                    :src="lightThemeImage"
                                    @click="styleTheme='light'">
                            </div>
                        </div>
                        <p><strong>{{ language.choose_place_btn }}</strong></p>
                        <div class="row justify-content-center p-3">
                            <div class="col-md-6 text-center p-3">
                                <p class="p-2">{{ language.btn_right }}</p>
                                <input type="radio" name="radioButtonPosition" id="radioButtonPositionRight" v-model="buttonPosition"
                                    value="right">
                                <img class="themeImage"
                                    src="<?php echo plugins_url('../img/button-on-right.png', __FILE__ ); ?>"
                                    @click="buttonPosition='right'">
                            </div>
                            <div class="col-md-6 text-center p-3">
                                <p class="p-2">{{ language.btn_left }}</p>
                                <input type="radio" name="radioButtonPosition" id="radioButtonPositionLeft"
                                    v-model="buttonPosition" value="left">
                                <img class="themeImage"
                                src="<?php echo plugins_url('../img/button-on-left.png', __FILE__ ); ?>"
                                    @click="buttonPosition='left'">
                            </div>
                        </div>
                        <p><strong>{{ language.manual_configuration }}</strong></p>
                        <div class="row">
                            <div class="col-sm-6 mt-2">
                                <p class="p-2">{{ language.full_code_description }}</p>
                                <div class="input-group">
                                    <textarea class="form-control" id="exampleFormControlTextarea1"
                                        readonly>{{fullcode}}</textarea>
                                    <div class="input-group-prepend pointer">
                                        <div class="input-group-text" @click="copyToClipboard(fullcode)">{{ language.copy }}</div>
                                    </div>
                                    <!-- <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Username"> -->
                                </div>
                            </div>
                            <div class="col-sm-6 mt-2">
                                <p class="p-2">{{ language.short_code_description }}</p>
                                <div class="input-group">
                                    <textarea class="form-control" id="exampleFormControlTextarea1"
                                        readonly>{{shortcode}}</textarea>
                                    <div class="input-group-prepend pointer">
                                        <div class="input-group-text" @click="copyToClipboard(shortcode)">{{ language.copy }}</div>
                                    </div>
                                    <!-- <input type="text" class="form-control" id="inlineFormInputGroupUsername" placeholder="Username"> -->
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="mt-3 text-center">
                        <form method="post" action="" >
                            <div class="form-hidden">
                                <input v-model="orgId" type="text" class="form-control custom-input"
                                        name="orgIdInput" aria-describedby="Organisation Id">
                                <input v-model="campaignName" type="text" class="form-control custom-input"
                                        name="campaignNameInput" aria-describedby="Campaign Name">
                                <input v-model="styleBtn" type="text" class="form-control custom-input"
                                        name="styleBtnInput" aria-describedby="StyleBtn">
                                <input v-model="styleTheme" type="text" class="form-control custom-input"
                                        name="styleThemeInput" aria-describedby="styleTheme">
                                <input v-model="buttonPosition" type="text" class="form-control custom-input"
                                        name="buttonPositionInput" aria-describedby="buttonPosition">
                            </div>
                            <button name="SaveClaimRewardSeedsConfig" class="btn btn-save">{{ language.save }}</button>
                        </form>
                    </div>
                </div>
                <!-- <div class="tab-pane fade" id="othervoice" role="tabpanel" aria-labelledby="othervoice-tab">
                    <div class="custom-card">
                        Lorem ipsum dolor sit amet consectetur adipisicing elit. Nesciunt, velit dolorem, facilis
                        iure, ipsa debitis temporibus numquam neque consequuntur dolorum facere enim quisquam amet?
                        Provident nostrum tempore excepturi aliquam vel.
                    </div>
                </div> -->
            </div>
        </div>
    </div>
    </div>
</body>
<script>
    const myStorage = window.localStorage;
    var app = new Vue({
        el: '#app',
        data: {
            orgId: undefined,
            campaignName: undefined,
            styleBtn: undefined,
            styleTheme: undefined,
            buttonPosition: undefined,
            selectedLanguage: undefined,
            translates: undefined
        },
        async beforeMount () {
            this.translates = await this.getTranslates()
            this.selectedLanguage = this.getDefaultLanguage()
        },
        mounted() {
            this.orgId = this.fetchOrgId();
            this.campaignName = this.fetchCampaignName();
            this.styleBtn = this.fetchStyleBtn();
            this.styleTheme = this.fetchStyleTheme();
            this.buttonPosition = this.fetchButtonPosition();
        },
        computed: {
            shortcode() {
                const id = Math.floor(Math.random() * 16777215).toString(16);
                return `[shortJoinSeeds id="${id}" org_id="${this.pk}" campaign_name="${this.campaignName}" btnStyle="${this.styleBtn}" multiStepStyle="${this.styleTheme}" buttonPosition="${this.buttonPosition}"]`;
            },
            fullcode () {
                const id = Math.floor(Math.random() * 16777215).toString(16);
                const classContainer = (this.buttonPosition === 'right')? "seed-btn-bottom-right": "seed-btn-bottom-left";
                let code = "<div id='claim-reward-seeds-"+id+"' class='"+classContainer+"'></div>\n";
                code += "<script src=\"https://seeds-cdn.s3.amazonaws.com/js/claimreward.js\"></"+"script>\n";
                code += "<script>\n";
                code += `new ClaimRewardSeed`+"("+`\"claim-reward-seeds-${id}\", {\"org_id\":\"${this.pk}\",\"campaign_name\":\"${this.campaignName}\",\"button_theme\":\"${this.styleBtn}\",\"multistep_theme\":\"${this.styleTheme}\"}`+"\)"+`;`;
                code += "\n</"+"script>";
                
                return code;
            },
            labelLanguage () {
                if (this.selectedLanguage) {
                    return this.selectedLanguage.label
                } else return 'Language'
            },
            language () {
                if (this.translates && this.selectedLanguage && this.selectedLanguage.key) { 
                    return this.translates[this.selectedLanguage.key]
                } return {}
            },
            darkThemeImage () {
                let uri = <?php echo '"'.plugins_url('../img/', __FILE__ ).'"'; ?>;
                const imageName = "/dark-theme.png"
                const languageFolder = this.selectedLanguage ? this.selectedLanguage.key : "en"
                return uri + languageFolder + imageName
            },
            lightThemeImage () {
                let uri = <?php echo '"'.plugins_url('../img/', __FILE__ ).'"'; ?>;
                const imageName = "/light-theme.png"
                const languageFolder = this.selectedLanguage ? this.selectedLanguage.key : "en"
                return uri + languageFolder + imageName
            }
        },
        methods: {
            setPreferredLanguage (language) {
                this.selectedLanguage = language
                myStorage.setItem('language_preferred', language.key)
            },
            getDefaultLanguage () {
                let lang = window.navigator.languages ? window.navigator.languages[0] : null;
                lang = lang || window.navigator.language || window.navigator.browserLanguage || window.navigator.userLanguage;

                let shortLang = lang;
                if (shortLang.indexOf('-') !== -1)
                    shortLang = shortLang.split('-')[0];

                if (shortLang.indexOf('_') !== -1)
                    shortLang = shortLang.split('_')[0];

                    // Get language saved
                    const keyLang = myStorage.getItem('language_preferred') ? myStorage.getItem('language_preferred') : shortLang
                    
                    // console.log(lang, shortLang);
                    const langSelected = this.translates.languages.find(v => v.key === keyLang)
                    // debugger
                return langSelected
            },
            async getTranslates () {
                const uri = <?php echo '"'.plugins_url('translates.json', __FILE__ ).'";'; ?>
                // const json = await (await fetch(uri)).json()
                const json = await (await fetch(uri)).json()
                console.log('json: ', json)
                return json
            },
            copyToClipboard(text) {
                // var text = this.shortcode;
                navigator.clipboard.writeText(text).then(() => {
                    // https://www.cssscript.com/super-simple-javascript-message-toaster-toast-js/
                    iqwerty.toast.toast(this.language.copy_success, {
                        settings: {
                            duration: 2000,
                        }
                    });

                }, function (err) {
                    iqwerty.toast.toast(this.language.copy_error, {
                        settings: {
                            duration: 2000,
                        }
                    });
                });
            },
            fetchOrgId () {
                const pk = <?php 
                    $data = $wpdb->get_row("SELECT org_id FROM {$wpdb->prefix}seeds_claim_reward_config where id=1"); 
                    echo "\"".$data->org_id."\"";
                ?>;
                return pk
            },
            fetchCampaignName () {
                return <?php 
                    $data = $wpdb->get_row("SELECT campaign_name FROM {$wpdb->prefix}seeds_claim_reward_config where id=1"); 
                    echo "\"".$data->campaign_name."\"";
                ?>;
            },
            fetchStyleBtn () {
                return <?php 
                    $data = $wpdb->get_row("SELECT style_btn FROM {$wpdb->prefix}seeds_claim_reward_config where id=1"); 
                    echo "\"".$data->style_btn."\"";
                ?>;
            },
            fetchStyleTheme () {
                return <?php 
                    $data = $wpdb->get_row("SELECT style_theme FROM {$wpdb->prefix}seeds_claim_reward_config where id=1"); 
                    echo "\"".$data->style_theme."\"";
                ?>;
            },
            fetchButtonPosition () {
                return <?php 
                    $data = $wpdb->get_row("SELECT button_position FROM {$wpdb->prefix}seeds_claim_reward_config where id=1"); 
                    echo "\"".$data->button_position."\"";
                ?>;
            }
        }
    });
</script>
</html>