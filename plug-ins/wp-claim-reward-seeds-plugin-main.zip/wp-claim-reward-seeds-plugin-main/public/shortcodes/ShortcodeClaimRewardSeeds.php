<?php
// require_once dirname(__FILE__)."../../admin/seeds/widgets/widgets-seeds/assets/js/widget/paywithseeds/paywithseeds.js";

class ShortcodeClaimRewardSeeds {

    function __construct(string $id, string $org_id, string $campaign_name, string $btnStyle, string $multiStepStyle)
    {
        $this->id = $id;
        $this->org_id = $org_id;
        $this->campaign_name = $campaign_name;
        $this->btnStyle = $btnStyle;
        $this->multiStepStyle = $multiStepStyle;
    }

    private function renderBtn() {
        $button = "<div>
            <button onclick=\"alert('$this->alert')\">JoinSeeds!</button>
        </div>";
        return $button;
    }

    private function renderJoinSeeds() {
        $html = "<div id='claim-reward-seeds_".$this->id."'></div>
        <script type=\"text/javascript\">
 
            loadScript = function (url) {
                return new Promise((resolve, reject) => {
                    setTimeout(function () { resolve() }, 400);
                    var script = document.createElement('script');
                    script.onload = function () {
                        resolve();
                    };
                    script.src = url;
                    
                    // document.head.appendChild(script);
                });
            }
            
            loadScript('../wordpress/wp-content/plugins/seeds-wp/admin/seeds/widgets/widgets-seeds/assets/js/widget/claimreward/claimreward.js ').then(() => {
                console.log('origin loaded: claim-reward-seeds_".$this->id."', '".$this->multiStepStyle."');
                new ClaimRewardSeed('claim-reward-seeds_".$this->id."', {'org_id':'".$this->org_id."','campaign_name':'".$this->campaign_name."','button_theme':'".$this->btnStyle."','multistep_theme':'".$this->multiStepStyle."'} );
            })

        </script>";
        return $html;
    }

    private function renderTitle() {
        $title = "<div>
        <p>$this->id</p>
        <p>$this->org_id</p>
        <p>$this->campaign_name</p>
        <p>$this->btnStyle</p>
        <p>$this->multiStepStyle</p>
        </div>";
        return $title;
    }

    public function render () {
        $html = "";
        // $html .= $this->renderTitle();
        $html .= $this->renderJoinSeeds();
        // $html .= $this->renderBtn();
        return $html;
    }
}