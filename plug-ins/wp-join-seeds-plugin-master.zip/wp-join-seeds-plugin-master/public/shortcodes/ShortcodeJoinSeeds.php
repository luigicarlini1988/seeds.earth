<?php
// require_once dirname(__FILE__)."../../admin/seeds/widgets/widgets-seeds/assets/js/widget/paywithseeds/paywithseeds.js";

class ShortcodeJoinSeeds {

    function __construct(string $id, string $account_name, string $campaign_name, string $btnStyle, string $multiStepStyle, string $buttonPosition)
    {
        $this->id = $id;
        $this->account_name = $account_name;
        $this->campaign_name = $campaign_name;
        $this->btnStyle = $btnStyle;
        $this->multiStepStyle = $multiStepStyle;
        $this->buttonPosition = $buttonPosition;
    }

    private function renderBtn() {
        $button = "<div>
            <button onclick=\"alert('$this->alert')\">JoinSeeds!</button>
        </div>";
        return $button;
    }

    private function renderJoinSeeds() {
        if ($this->buttonPosition === "right") {
            $html = "<div id='".$this->buttonPosition."' class='join-seed-btn-bottom-right'><div id='join-seeds_".$this->id."'></div></div>";
        } else {
            $html = "<div id=".$this->buttonPosition." class='join-seed-btn-bottom-left'><div id='join-seeds_".$this->id."'></div></div>";
        }

        $html .= "<script type=\"text/javascript\">
 
            loadScript = function (url) {
                return new Promise((resolve, reject) => {
                    var script = document.createElement('script');
                    script.onload = function () {
                        resolve();
                    };
                    script.src = url;
            
                    document.head.appendChild(script);
                });
            }
            loadScript('https://seeds-cdn.s3.amazonaws.com/js/joinseeds.js').then(() => {
                new JoinSeeds('join-seeds_".$this->id."', {'account_name':'".$this->account_name."','campaign_name':'".$this->campaign_name."','button_theme':'".$this->btnStyle."','multistep_theme':'".$this->multiStepStyle."'} );
            })

        </script>";
        return $html;
    }

    private function renderTitle() {
        $title = "<div>
        <p>$this->id</p>
        <p>$this->org_id</p>
        <p>$this->campaign_name</p>
        <p>$this->multiStepStyle</p>
        </div>";
        return $title;
    }

    public function render () {
        $html = "";
        // $html .= $this->renderTitle();
        $html .= $this->renderJoinSeeds();
        // $html .= $this->renderBtn();
        return $html;
    }
}