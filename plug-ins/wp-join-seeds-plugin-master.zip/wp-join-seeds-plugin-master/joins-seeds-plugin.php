<?php
/*
Plugin Name: Join Seeds
Plugin URI: https://joinseeds.earth/join-seeds
Description: Join to Seeds
Version: 0.1.6
*/

//Import class
require_once dirname(__FILE__)."/public/shortcodes/ShortcodeJoinSeeds.php";

require_once dirname(__FILE__)."/admin/configs/svgIcon.php";

function ActivateJoinSeedsPlugin() {
    // echo 'Activate';
    global $wpdb;

    $SQL = "CREATE TABLE IF NOT EXISTS {$wpdb->prefix}seeds_join_config
    (
    `id` INT NOT NULL ,
    `org_id` VARCHAR(100) NOT NULL ,
    `campaign_name` VARCHAR(100) NOT NULL,
    `style_btn` VARCHAR(100) NOT NULL,
    `style_theme` VARCHAR(100) NOT NULL,
    `button_position` VARCHAR(100) NOT NULL,
    PRIMARY KEY (`id`)
    ) ENGINE = InnoDB COMMENT = 'Seeds Plugin (JoinSeeds)';";

    $wpdb->query($SQL);
}

// function Desactivate () {
// }

register_activation_hook(__FILE__,'ActivateJoinSeedsPlugin');
// register_deactivation_hook(__FILE__,'Desactivate');

#Add menu
add_action('admin_menu','create_joins_seeds_menu');

function create_joins_seeds_menu () {
    
    $icon_data_uri = 'data:image/svg+xml;base64,' . getJoinSeedsIcon();

    // Main menu
    add_menu_page(
      'Join Seeds', // Title page
      'Join Seeds', // Title menu
      'manage_options', // Role allowed
      plugin_dir_path(__FILE__).'admin/configs/joins-seeds-config.php', // Slug
      null, // Function to render
      //   plugin_dir_url(__FILE__).'admin/img/icon-join.png',
      $icon_data_uri,
      '2'
    );
}

// Import Css
function import_js_to_joins_seeds ($hook) {
    //Admin
    // if (str_contains($hook, 'admin/configs/joins-seeds-config.php')) {
    if (strpos($hook, 'admin/configs/joins-seeds-config.php') !== false) {
        wp_enqueue_script('VueJs','https://cdn.jsdelivr.net/npm/vue@2/dist/vue.js'); 
        wp_enqueue_script('BootsrapJS',plugins_url('includes/bootstrap-4.6.0-dist/js/bootstrap.bundle.min.js', __FILE__));
        wp_enqueue_script('Toast',plugins_url('includes/js-toast-master/toast.min.js', __FILE__));
    } 
}

// global styles
function add_stylesheet_to_head() {
    echo "<link href='".plugins_url('public/css/button-positions.css', __FILE__)."' rel='stylesheet' type='text/css'>";
}

function import_css_to_joins_seeds ($hook) {
    // if (str_contains($hook, 'admin/configs/joins-seeds-config.php')) {
    if (strpos($hook, 'admin/configs/joins-seeds-config.php') !== false) {
        wp_enqueue_style('BootsrapCSS',plugins_url('includes/bootstrap-4.6.0-dist/css/bootstrap.css', __FILE__));
        wp_enqueue_style('BootsrapCSS2',plugins_url('includes/bootstrap-4.6.0-dist/css/bootstrap-grid.css', __FILE__));
        wp_enqueue_style('Main',plugins_url('admin/configs/css/main.css', __FILE__));
    }
}

function renderShortJoinSeeds ($attrs) {
    // var_dump($attrs);
    $id = $attrs['id'] ?: '1';
    $account_name = $attrs['account_name'] ?: 'Testing';
    $campaign_name = $attrs['campaign_name'] ?: 'Testing';
    $btnStyle = $attrs['btnstyle'] ?: 'light';
    $multiStepStyle = $attrs['multistepstyle'] ?: 'light';
    $buttonPosition = $attrs['buttonposition'] ?: 'left';

    // wp_enqueue_script('seeds_pay_qrcode_js',plugins_url('admin/seeds/widgets/widgets-seeds/paywithseeds/node_modules/qrcode/build/qrcode.min.js', __FILE__), array('jquery'), NULL, true);
    $shortJoinSeeds = new ShortcodeJoinSeeds($id, $account_name, $campaign_name, $btnStyle, $multiStepStyle, $buttonPosition);
    return $shortJoinSeeds->render();
}

// Add global styles
add_action( 'wp_head', 'add_stylesheet_to_head' );

//Import js
add_action('admin_enqueue_scripts','import_js_to_joins_seeds');

//Import css
add_action('admin_enqueue_scripts','import_css_to_joins_seeds');

//Add shortcode
add_shortcode('shortJoinSeeds', 'renderShortJoinSeeds');